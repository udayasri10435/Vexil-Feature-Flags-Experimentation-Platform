import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  AuditLog,
  Environment,
  EvaluationResult,
  Experiment,
  FeatureFlag,
  Segment,
  UserContext,
} from '../types';
import {
  INITIAL_AUDIT_LOGS,
  INITIAL_EXPERIMENTS,
  INITIAL_FLAGS,
  INITIAL_SEGMENTS,
  SAMPLE_USER_CONTEXTS,
} from '../data/initialData';
import { evaluateFlag } from '../utils/evaluator';
import { simulateExperimentTraffic } from '../utils/statistics';

interface FlagContextType {
  environment: Environment;
  setEnvironment: (env: Environment) => void;
  flags: FeatureFlag[];
  experiments: Experiment[];
  segments: Segment[];
  auditLogs: AuditLog[];
  currentUserContext: UserContext;
  setCurrentUserContext: (ctx: UserContext) => void;
  toggleFlag: (flagId: string, env: Environment) => void;
  updateFlag: (flag: FeatureFlag, logSummary?: string) => void;
  createFlag: (flag: FeatureFlag) => void;
  archiveFlag: (flagId: string) => void;
  deleteFlag: (flagId: string) => void;
  tripKillSwitch: (flagId: string, env: Environment) => void;
  startExperiment: (expId: string) => void;
  pauseExperiment: (expId: string) => void;
  concludeExperiment: (expId: string, winnerVariationId: string, promoteToProduction: boolean) => void;
  simulateTraffic: (expId: string, visitors: number) => void;
  createExperiment: (exp: Experiment) => void;
  promoteCanary: (flagId: string, env: Environment) => void;
  rollbackCanary: (flagId: string, env: Environment) => void;
  createSegment: (segment: Segment) => void;
  updateSegment: (segment: Segment) => void;
  deleteSegment: (segmentId: string) => void;
  evaluateFlagForUser: (flagKeyOrId: string, env?: Environment, user?: UserContext) => EvaluationResult | null;
  evaluateAllFlagsForUser: (env?: Environment, user?: UserContext) => Record<string, EvaluationResult>;
  recordLiveConversion: (metricKey: string, flagKey?: string) => void;
  resetToSampleData: () => void;
  exportStateJson: () => string;
  importStateJson: (jsonStr: string) => boolean;
}

const FlagContext = createContext<FlagContextType | undefined>(undefined);

const STORAGE_KEYS = {
  FLAGS: 'vexil_flags_v1',
  EXPERIMENTS: 'vexil_experiments_v1',
  SEGMENTS: 'vexil_segments_v1',
  AUDIT_LOGS: 'vexil_audit_logs_v1',
  ENV: 'vexil_env_v1',
  USER: 'vexil_user_v1',
};

export const FlagProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [environment, setEnvironmentState] = useState<Environment>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ENV);
      return saved === 'staging' || saved === 'development' || saved === 'production' ? saved : 'production';
    } catch {
      return 'production';
    }
  });

  const [flags, setFlags] = useState<FeatureFlag[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FLAGS);
      return saved ? JSON.parse(saved) : INITIAL_FLAGS;
    } catch {
      return INITIAL_FLAGS;
    }
  });

  const [experiments, setExperiments] = useState<Experiment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.EXPERIMENTS);
      return saved ? JSON.parse(saved) : INITIAL_EXPERIMENTS;
    } catch {
      return INITIAL_EXPERIMENTS;
    }
  });

  const [segments, setSegments] = useState<Segment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SEGMENTS);
      return saved ? JSON.parse(saved) : INITIAL_SEGMENTS;
    } catch {
      return INITIAL_SEGMENTS;
    }
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
    } catch {
      return INITIAL_AUDIT_LOGS;
    }
  });

  const [currentUserContext, setCurrentUserContext] = useState<UserContext>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USER);
      return saved ? JSON.parse(saved) : SAMPLE_USER_CONTEXTS[0];
    } catch {
      return SAMPLE_USER_CONTEXTS[0];
    }
  });

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.FLAGS, JSON.stringify(flags));
    } catch (e) {
      console.warn('Failed saving flags to storage', e);
    }
  }, [flags]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.EXPERIMENTS, JSON.stringify(experiments));
    } catch (e) {
      console.warn('Failed saving experiments to storage', e);
    }
  }, [experiments]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SEGMENTS, JSON.stringify(segments));
    } catch (e) {
      console.warn('Failed saving segments to storage', e);
    }
  }, [segments]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(auditLogs));
    } catch (e) {
      console.warn('Failed saving audit logs to storage', e);
    }
  }, [auditLogs]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ENV, environment);
    } catch (e) {
      console.warn('Failed saving env to storage', e);
    }
  }, [environment]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUserContext));
    } catch (e) {
      console.warn('Failed saving user to storage', e);
    }
  }, [currentUserContext]);

  const addLog = (log: Omit<AuditLog, 'id' | 'timestamp'>) => {
    const newLog: AuditLog = {
      ...log,
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newLog, ...prev.slice(0, 199)]);
  };

  const setEnvironment = (env: Environment) => {
    setEnvironmentState(env);
  };

  const toggleFlag = (flagId: string, env: Environment) => {
    const flag = flags.find((f) => f.id === flagId);
    if (!flag) return;

    const currentEnvState = flag.environments[env];
    const nextState = !currentEnvState.enabled;

    setFlags((prev) =>
      prev.map((f) => {
        if (f.id !== flagId) return f;
        return {
          ...f,
          updatedAt: new Date().toISOString(),
          environments: {
            ...f.environments,
            [env]: {
              ...f.environments[env],
              enabled: nextState,
            },
          },
        };
      })
    );

    addLog({
      actor: { name: 'Demo Engineer (You)', email: 'engineer@acme-corp.com', role: 'Staff Platform Eng' },
      action: 'FLAG_TOGGLED',
      entityType: 'flag',
      entityKey: flag.key,
      entityName: flag.name,
      environment: env,
      summary: `Toggled flag ${nextState ? 'ON' : 'OFF'} in [${env}]`,
      diff: [
        { field: `environments.${env}.enabled`, oldValue: currentEnvState.enabled, newValue: nextState },
      ],
    });
  };

  const tripKillSwitch = (flagId: string, env: Environment) => {
    const flag = flags.find((f) => f.id === flagId);
    if (!flag) return;

    const currentEnvState = flag.environments[env];
    const isNowTripped = !currentEnvState.enabled;

    setFlags((prev) =>
      prev.map((f) => {
        if (f.id !== flagId) return f;
        return {
          ...f,
          updatedAt: new Date().toISOString(),
          environments: {
            ...f.environments,
            [env]: {
              ...f.environments[env],
              enabled: isNowTripped,
            },
          },
        };
      })
    );

    addLog({
      actor: { name: 'Emergency On-Call', email: 'security@acme-corp.com', role: 'Incident Commander' },
      action: 'KILL_SWITCH_TRIPPED',
      entityType: 'flag',
      entityKey: flag.key,
      entityName: flag.name,
      environment: env,
      summary: `EMERGENCY ACTION: Kill switch ${isNowTripped ? 'ENGAGED' : 'DEACTIVATED'} in [${env}]`,
    });
  };

  const updateFlag = (updatedFlag: FeatureFlag, logSummary?: string) => {
    setFlags((prev) =>
      prev.map((f) => (f.id === updatedFlag.id ? { ...updatedFlag, updatedAt: new Date().toISOString() } : f))
    );

    addLog({
      actor: { name: 'Demo Engineer (You)', email: 'engineer@acme-corp.com', role: 'Staff Platform Eng' },
      action: 'FLAG_UPDATED',
      entityType: 'flag',
      entityKey: updatedFlag.key,
      entityName: updatedFlag.name,
      summary: logSummary || `Updated targeting and variations for flag ${updatedFlag.key}`,
    });
  };

  const createFlag = (newFlag: FeatureFlag) => {
    setFlags((prev) => [newFlag, ...prev]);
    addLog({
      actor: { name: 'Demo Engineer (You)', email: 'engineer@acme-corp.com', role: 'Staff Platform Eng' },
      action: 'FLAG_CREATED',
      entityType: 'flag',
      entityKey: newFlag.key,
      entityName: newFlag.name,
      summary: `Created new ${newFlag.category} flag "${newFlag.name}" (${newFlag.key})`,
    });
  };

  const archiveFlag = (flagId: string) => {
    const flag = flags.find((f) => f.id === flagId);
    if (!flag) return;

    setFlags((prev) =>
      prev.map((f) => (f.id === flagId ? { ...f, archived: !f.archived, updatedAt: new Date().toISOString() } : f))
    );

    addLog({
      actor: { name: 'Demo Engineer (You)', email: 'engineer@acme-corp.com', role: 'Staff Platform Eng' },
      action: 'FLAG_UPDATED',
      entityType: 'flag',
      entityKey: flag.key,
      entityName: flag.name,
      summary: `${flag.archived ? 'Restored' : 'Archived'} flag ${flag.key}`,
    });
  };

  const deleteFlag = (flagId: string) => {
    const flag = flags.find((f) => f.id === flagId);
    if (!flag) return;

    setFlags((prev) => prev.filter((f) => f.id !== flagId));
    addLog({
      actor: { name: 'Demo Engineer (You)', email: 'engineer@acme-corp.com', role: 'Staff Platform Eng' },
      action: 'FLAG_UPDATED',
      entityType: 'flag',
      entityKey: flag.key,
      entityName: flag.name,
      summary: `Permanently deleted feature flag "${flag.name}"`,
    });
  };

  const startExperiment = (expId: string) => {
    setExperiments((prev) =>
      prev.map((e) =>
        e.id === expId ? { ...e, status: 'running', startedAt: e.startedAt || new Date().toISOString() } : e
      )
    );

    const exp = experiments.find((e) => e.id === expId);
    if (exp) {
      addLog({
        actor: { name: 'Product Growth', email: 'growth@acme-corp.com', role: 'Growth PM' },
        action: 'EXPERIMENT_STARTED',
        entityType: 'experiment',
        entityKey: exp.key,
        entityName: exp.name,
        environment: exp.environment,
        summary: `Started experiment "${exp.name}" on ${exp.environment}`,
      });
    }
  };

  const pauseExperiment = (expId: string) => {
    setExperiments((prev) => prev.map((e) => (e.id === expId ? { ...e, status: 'paused' } : e)));
  };

  const concludeExperiment = (expId: string, winnerVariationId: string, promoteToProduction: boolean) => {
    const exp = experiments.find((e) => e.id === expId);
    if (!exp) return;

    setExperiments((prev) =>
      prev.map((e) =>
        e.id === expId
          ? {
              ...e,
              status: 'concluded',
              concludedAt: new Date().toISOString(),
              winnerVariationId,
            }
          : e
      )
    );

    if (promoteToProduction) {
      // Roll out winning variation to 100% of production traffic for associated flag
      setFlags((prev) =>
        prev.map((f) => {
          if (f.id !== exp.flagId) return f;
          return {
            ...f,
            updatedAt: new Date().toISOString(),
            environments: {
              ...f.environments,
              production: {
                ...f.environments.production,
                enabled: true,
                fallthrough: {
                  type: 'single',
                  variationId: winnerVariationId,
                },
              },
            },
          };
        })
      );
    }

    addLog({
      actor: { name: 'Lead Data Scientist', email: 'stats@acme-corp.com', role: 'Experimentation Lead' },
      action: 'EXPERIMENT_CONCLUDED',
      entityType: 'experiment',
      entityKey: exp.key,
      entityName: exp.name,
      environment: exp.environment,
      summary: `Concluded experiment "${exp.name}". Declared variation winner. ${
        promoteToProduction ? 'Promoted winning variation to 100% Production fallthrough!' : ''
      }`,
    });
  };

  const simulateTraffic = (expId: string, visitors: number) => {
    const exp = experiments.find((e) => e.id === expId);
    if (!exp) return;

    // True lift rates for realistic simulation
    const trueCr = 0.11;
    const liftDeltas: Record<string, number> = {};
    exp.variations.forEach((v, idx) => {
      // baseline gets delta 0, variants get subtle positive or negative delta
      liftDeltas[v.variationId] = idx === 0 ? 0 : 0.024 + idx * 0.005;
    });

    const updatedStats = simulateExperimentTraffic(
      exp.stats,
      visitors,
      trueCr,
      liftDeltas,
      exp.baselineVariationId,
      exp.confidenceLevel
    );

    setExperiments((prev) =>
      prev.map((e) => {
        if (e.id !== expId) return e;
        return {
          ...e,
          stats: updatedStats,
        };
      })
    );
  };

  const createExperiment = (newExp: Experiment) => {
    setExperiments((prev) => [newExp, ...prev]);
    addLog({
      actor: { name: 'Growth Team', email: 'growth@acme-corp.com', role: 'Growth PM' },
      action: 'EXPERIMENT_STARTED',
      entityType: 'experiment',
      entityKey: newExp.key,
      entityName: newExp.name,
      environment: newExp.environment,
      summary: `Created experiment "${newExp.name}" with metric ${newExp.primaryMetric.name}`,
    });
  };

  const promoteCanary = (flagId: string, env: Environment) => {
    const flag = flags.find((f) => f.id === flagId);
    if (!flag || !flag.environments[env].canary) return;

    const canary = flag.environments[env].canary!;
    const nextIndex = Math.min(canary.currentStageIndex + 1, canary.stages.length - 1);
    const stage = canary.stages[nextIndex];

    const updatedStages = canary.stages.map((s, idx) => {
      if (idx < nextIndex) return { ...s, status: 'passed' as const };
      if (idx === nextIndex) return { ...s, status: 'active' as const };
      return { ...s, status: 'pending' as const };
    });

    setFlags((prev) =>
      prev.map((f) => {
        if (f.id !== flagId) return f;
        return {
          ...f,
          updatedAt: new Date().toISOString(),
          environments: {
            ...f.environments,
            [env]: {
              ...f.environments[env],
              canary: {
                ...canary,
                currentStageIndex: nextIndex,
                stages: updatedStages,
              },
            },
          },
        };
      })
    );

    addLog({
      actor: { name: 'Canary SRE', email: 'sre@acme-corp.com', role: 'Reliability Engineer' },
      action: 'CANARY_PROMOTED',
      entityType: 'canary',
      entityKey: flag.key,
      entityName: flag.name,
      environment: env,
      summary: `Promoted canary to Stage ${stage.stage} (${stage.percentage}% traffic)`,
    });
  };

  const rollbackCanary = (flagId: string, env: Environment) => {
    const flag = flags.find((f) => f.id === flagId);
    if (!flag || !flag.environments[env].canary) return;

    const canary = flag.environments[env].canary!;
    const updatedStages = canary.stages.map((s, idx) => ({
      ...s,
      status: idx === 0 ? ('active' as const) : ('pending' as const),
    }));

    setFlags((prev) =>
      prev.map((f) => {
        if (f.id !== flagId) return f;
        return {
          ...f,
          updatedAt: new Date().toISOString(),
          environments: {
            ...f.environments,
            [env]: {
              ...f.environments[env],
              canary: {
                ...canary,
                currentStageIndex: 0,
                circuitBreakerTripped: true,
                stages: updatedStages,
              },
            },
          },
        };
      })
    );

    addLog({
      actor: { name: 'Canary Circuit Breaker', email: 'telemetry@acme-corp.com', role: 'Automated SRE' },
      action: 'CANARY_ROLLED_BACK',
      entityType: 'canary',
      entityKey: flag.key,
      entityName: flag.name,
      environment: env,
      summary: `CIRCUIT BREAKER: Rolled back canary to Stage 1 and engaged circuit breaker for ${flag.key}`,
    });
  };

  const createSegment = (segment: Segment) => {
    setSegments((prev) => [...prev, segment]);
    addLog({
      actor: { name: 'Demo Engineer (You)', email: 'engineer@acme-corp.com', role: 'Staff Platform Eng' },
      action: 'SEGMENT_UPDATED',
      entityType: 'segment',
      entityKey: segment.key,
      entityName: segment.name,
      summary: `Created reusable segment "${segment.name}" (${segment.key})`,
    });
  };

  const updateSegment = (segment: Segment) => {
    setSegments((prev) => prev.map((s) => (s.id === segment.id ? segment : s)));
    addLog({
      actor: { name: 'Demo Engineer (You)', email: 'engineer@acme-corp.com', role: 'Staff Platform Eng' },
      action: 'SEGMENT_UPDATED',
      entityType: 'segment',
      entityKey: segment.key,
      entityName: segment.name,
      summary: `Updated segment rules for "${segment.name}"`,
    });
  };

  const deleteSegment = (segmentId: string) => {
    setSegments((prev) => prev.filter((s) => s.id !== segmentId));
  };

  const evaluateFlagForUser = (
    flagKeyOrId: string,
    env: Environment = environment,
    user: UserContext = currentUserContext
  ): EvaluationResult | null => {
    const flag = flags.find((f) => f.key === flagKeyOrId || f.id === flagKeyOrId);
    if (!flag) return null;
    return evaluateFlag(flag, env, user, segments);
  };

  const evaluateAllFlagsForUser = (
    env: Environment = environment,
    user: UserContext = currentUserContext
  ): Record<string, EvaluationResult> => {
    const results: Record<string, EvaluationResult> = {};
    for (const flag of flags) {
      results[flag.key] = evaluateFlag(flag, env, user, segments);
    }
    return results;
  };

  // Called when demo storefront user does a conversion action (e.g. completes checkout or performs search)
  const recordLiveConversion = (metricKey: string, flagKey?: string) => {
    // Find active experiments matching this metric or flag
    const targetExps = experiments.filter(
      (e) =>
        e.status === 'running' &&
        (e.primaryMetric.key === metricKey || (flagKey && flags.find((f) => f.id === e.flagId)?.key === flagKey))
    );

    if (targetExps.length === 0) return;

    for (const exp of targetExps) {
      const flag = flags.find((f) => f.id === exp.flagId);
      if (!flag) continue;
      const evalRes = evaluateFlag(flag, exp.environment, currentUserContext, segments);
      const varId = evalRes.variationId;

      if (exp.stats[varId]) {
        // Increment conversion for this user's variation
        const stat = { ...exp.stats[varId] };
        stat.conversions += 1;
        stat.sampleSize += 1;
        stat.conversionRate = Number(((stat.conversions / stat.sampleSize) * 100).toFixed(2));

        const updatedStats = {
          ...exp.stats,
          [varId]: stat,
        };

        setExperiments((prev) =>
          prev.map((e) => (e.id === exp.id ? { ...e, stats: updatedStats } : e))
        );
      }
    }
  };

  const resetToSampleData = () => {
    setFlags(INITIAL_FLAGS);
    setExperiments(INITIAL_EXPERIMENTS);
    setSegments(INITIAL_SEGMENTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setEnvironmentState('production');
    setCurrentUserContext(SAMPLE_USER_CONTEXTS[0]);
    localStorage.clear();
  };

  const exportStateJson = () => {
    const backup = {
      exportedAt: new Date().toISOString(),
      flags,
      experiments,
      segments,
      auditLogs,
    };
    return JSON.stringify(backup, null, 2);
  };

  const importStateJson = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.flags && Array.isArray(data.flags)) {
        setFlags(data.flags);
      }
      if (data.experiments && Array.isArray(data.experiments)) {
        setExperiments(data.experiments);
      }
      if (data.segments && Array.isArray(data.segments)) {
        setSegments(data.segments);
      }
      if (data.auditLogs && Array.isArray(data.auditLogs)) {
        setAuditLogs(data.auditLogs);
      }
      return true;
    } catch {
      return false;
    }
  };

  return (
    <FlagContext.Provider
      value={{
        environment,
        setEnvironment,
        flags,
        experiments,
        segments,
        auditLogs,
        currentUserContext,
        setCurrentUserContext,
        toggleFlag,
        updateFlag,
        createFlag,
        archiveFlag,
        deleteFlag,
        tripKillSwitch,
        startExperiment,
        pauseExperiment,
        concludeExperiment,
        simulateTraffic,
        createExperiment,
        promoteCanary,
        rollbackCanary,
        createSegment,
        updateSegment,
        deleteSegment,
        evaluateFlagForUser,
        evaluateAllFlagsForUser,
        recordLiveConversion,
        resetToSampleData,
        exportStateJson,
        importStateJson,
      }}
    >
      {children}
    </FlagContext.Provider>
  );
};

export const useFlags = (): FlagContextType => {
  const context = useContext(FlagContext);
  if (!context) {
    throw new Error('useFlags must be used within a FlagProvider');
  }
  return context;
};
