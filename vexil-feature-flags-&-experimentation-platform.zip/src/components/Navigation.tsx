import React from 'react';
import {
  Activity,
  Boxes,
  Code2,
  FileClock,
  FlaskConical,
  Layers,
  Network,
  Sparkles,
  Users2,
} from 'lucide-react';
import { useFlags } from '../context/FlagContext';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const { flags, experiments, segments } = useFlags();

  const activeFlagsCount = flags.filter((f) => !f.archived).length;
  const runningExperimentsCount = experiments.filter((e) => e.status === 'running').length;
  const canariesCount = flags.filter((f) => f.environments.production?.canary?.enabled).length;

  const navItems = [
    {
      id: 'flags',
      label: 'Feature Flags',
      icon: Layers,
      count: activeFlagsCount,
    },
    {
      id: 'experiments',
      label: 'A/B Experiments',
      icon: FlaskConical,
      count: runningExperimentsCount,
      highlight: runningExperimentsCount > 0,
    },
    {
      id: 'canary',
      label: 'Canary Rollouts',
      icon: Activity,
      count: canariesCount,
    },
    {
      id: 'playground',
      label: 'SDK & Trace Playground',
      icon: Code2,
    },
    {
      id: 'storefront',
      label: 'Live Client App Sandbox',
      icon: Sparkles,
      tag: 'Interactive',
    },
    {
      id: 'segments',
      label: 'User Segments',
      icon: Users2,
      count: segments.length,
    },
    {
      id: 'audit',
      label: 'Audit Log & History',
      icon: FileClock,
    },
  ];

  return (
    <nav className="border-b border-slate-800 bg-slate-950 px-4 lg:px-8">
      <div className="flex space-x-1 overflow-x-auto py-2 scrollbar-none">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-2 rounded-md px-3.5 py-2 text-xs font-medium whitespace-nowrap transition-colors ${
                isActive
                  ? 'bg-slate-900 text-white shadow-inner font-semibold border-b-2 border-indigo-500'
                  : 'text-slate-400 hover:bg-slate-900/60 hover:text-slate-200'
              }`}
            >
              <Icon className={`h-4 w-4 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
              <span>{item.label}</span>

              {item.count !== undefined && (
                <span
                  className={`ml-1 text-[11px] font-mono font-semibold ${
                    item.highlight && isActive
                      ? 'text-emerald-400'
                      : isActive
                      ? 'text-indigo-300'
                      : 'text-slate-400'
                  }`}
                >
                  ({item.count})
                </span>
              )}

              {item.tag && (
                <span className="ml-1 text-[10px] uppercase font-bold tracking-wider text-indigo-400">
                  {item.tag}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
