import React from 'react';
import { ArrowDown, ArrowUp, Plus, Trash2, Sliders, Users } from 'lucide-react';
import { RuleOperator, Segment, TargetingRule, Variation } from '../../types';
import { RolloutSlider } from './RolloutSlider';

interface TargetingRulesEditorProps {
  rules: TargetingRule[];
  variations: Variation[];
  segments: Segment[];
  onChange: (rules: TargetingRule[]) => void;
  disabled?: boolean;
}

const COMMON_ATTRIBUTES = [
  { value: 'email', label: 'User Email (e.g. @acme.com)' },
  { value: 'plan', label: 'Subscription Plan (e.g. enterprise, pro)' },
  { value: 'country', label: 'Country Code (e.g. US, DE, GB)' },
  { value: 'role', label: 'Role (e.g. admin, developer, billing)' },
  { value: 'appVersion', label: 'Client App Version (e.g. 3.2.0)' },
  { value: 'key', label: 'User Unique Key / ID' },
  { value: 'isInternal', label: 'Is Internal Employee (boolean)' },
];

const OPERATORS: { value: RuleOperator; label: string }[] = [
  { value: 'equals', label: 'equals' },
  { value: 'not_equals', label: 'does not equal' },
  { value: 'contains', label: 'contains' },
  { value: 'not_contains', label: 'does not contain' },
  { value: 'ends_with', label: 'ends with (e.g. domain)' },
  { value: 'starts_with', label: 'starts with' },
  { value: 'in_list', label: 'is in list of values' },
  { value: 'not_in_list', label: 'is not in list' },
  { value: 'greater_than', label: 'is greater than (>)' },
  { value: 'less_than', label: 'is less than (<)' },
  { value: 'matches_regex', label: 'matches regex expression' },
  { value: 'in_segment', label: 'matches pre-defined segment' },
];

export const TargetingRulesEditor: React.FC<TargetingRulesEditorProps> = ({
  rules,
  variations,
  segments,
  onChange,
  disabled = false,
}) => {
  const handleAddRule = () => {
    const newRule: TargetingRule = {
      id: `rule-${Date.now()}`,
      description: 'New Targeting Rule',
      attribute: 'plan',
      operator: 'equals',
      values: ['enterprise'],
      serveType: 'single',
      serveVariationId: variations[0]?.id,
    };
    onChange([...rules, newRule]);
  };

  const handleUpdateRule = (ruleId: string, partial: Partial<TargetingRule>) => {
    onChange(rules.map((r) => (r.id === ruleId ? { ...r, ...partial } : r)));
  };

  const handleDeleteRule = (ruleId: string) => {
    onChange(rules.filter((r) => r.id !== ruleId));
  };

  const handleMoveRule = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= rules.length) return;
    const newRules = [...rules];
    const [moved] = newRules.splice(index, 1);
    newRules.splice(targetIndex, 0, moved);
    onChange(newRules);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-slate-200">Custom Targeting Rules</h3>
          <p className="text-xs text-slate-400">
            Rules evaluate in top-down sequential order. First matching rule determines served variation.
          </p>
        </div>
        <button
          type="button"
          onClick={handleAddRule}
          disabled={disabled}
          className="flex items-center gap-1.5 rounded-md border border-indigo-500/40 bg-indigo-500/10 px-3 py-1.5 text-xs font-semibold text-indigo-300 hover:bg-indigo-500/20 disabled:opacity-50"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>Add Targeting Rule</span>
        </button>
      </div>

      {rules.length === 0 ? (
        <div className="rounded-lg border border-dashed border-slate-800 p-6 text-center">
          <p className="text-xs text-slate-400">
            No custom targeting rules configured yet. All users fall through to default rollout.
          </p>
          <button
            type="button"
            onClick={handleAddRule}
            className="mt-3 text-xs font-medium text-indigo-400 hover:underline"
          >
            Create your first targeting rule →
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {rules.map((rule, idx) => (
            <div
              key={rule.id}
              className="rounded-lg border border-slate-800 bg-slate-900/80 p-4 transition-all hover:border-slate-700"
            >
              {/* Header: Rule number & Description & Order Buttons */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <span className="flex h-5 w-5 items-center justify-center rounded bg-slate-800 font-mono text-[11px] font-bold text-slate-300">
                    {idx + 1}
                  </span>
                  <input
                    type="text"
                    value={rule.description || ''}
                    placeholder="Rule description (e.g. Beta testers in US)"
                    onChange={(e) => handleUpdateRule(rule.id, { description: e.target.value })}
                    disabled={disabled}
                    className="border-b border-transparent bg-transparent px-1 py-0.5 text-xs font-semibold text-slate-200 placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleMoveRule(idx, 'up')}
                    disabled={idx === 0 || disabled}
                    title="Move rule up"
                    className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white disabled:opacity-30"
                  >
                    <ArrowUp className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleMoveRule(idx, 'down')}
                    disabled={idx === rules.length - 1 || disabled}
                    title="Move rule down"
                    className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white disabled:opacity-30"
                  >
                    <ArrowDown className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteRule(rule.id)}
                    disabled={disabled}
                    title="Delete rule"
                    className="rounded p-1 text-slate-400 hover:bg-rose-500/20 hover:text-rose-400 disabled:opacity-30"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* Condition Section */}
              <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-12">
                {/* Attribute */}
                <div className="sm:col-span-4">
                  <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
                    Attribute
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      list={`attributes-list-${rule.id}`}
                      value={rule.attribute}
                      onChange={(e) => handleUpdateRule(rule.id, { attribute: e.target.value })}
                      disabled={disabled}
                      placeholder="Select or enter attribute"
                      className="w-full rounded border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none font-mono"
                    />
                    <datalist id={`attributes-list-${rule.id}`}>
                      {COMMON_ATTRIBUTES.map((attr) => (
                        <option key={attr.value} value={attr.value}>
                          {attr.label}
                        </option>
                      ))}
                    </datalist>
                  </div>
                </div>

                {/* Operator */}
                <div className="sm:col-span-3">
                  <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
                    Condition
                  </label>
                  <select
                    value={rule.operator}
                    onChange={(e) => handleUpdateRule(rule.id, { operator: e.target.value as RuleOperator })}
                    disabled={disabled}
                    className="w-full rounded border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-xs text-slate-200 focus:border-indigo-500 focus:outline-none"
                  >
                    {OPERATORS.map((op) => (
                      <option key={op.value} value={op.value}>
                        {op.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Target Value(s) */}
                <div className="sm:col-span-5">
                  <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
                    Matching Value(s)
                  </label>
                  {rule.operator === 'in_segment' ? (
                    <select
                      value={rule.values[0] || ''}
                      onChange={(e) => handleUpdateRule(rule.id, { values: [e.target.value] })}
                      disabled={disabled}
                      className="w-full rounded border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-xs text-slate-200 focus:border-indigo-500 focus:outline-none"
                    >
                      <option value="">Select Segment...</option>
                      {segments.map((seg) => (
                        <option key={seg.key} value={seg.key}>
                          {seg.name} ({seg.key})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type="text"
                      value={rule.values.join(', ')}
                      placeholder="e.g. enterprise, pro (comma separated)"
                      onChange={(e) =>
                        handleUpdateRule(rule.id, {
                          values: e.target.value.split(',').map((v) => v.trim()).filter(Boolean),
                        })
                      }
                      disabled={disabled}
                      className="w-full rounded border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none font-mono"
                    />
                  )}
                </div>
              </div>

              {/* Serve Section */}
              <div className="mt-3.5 border-t border-slate-800/80 pt-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-indigo-300">THEN SERVE:</span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleUpdateRule(rule.id, { serveType: 'single' })}
                      className={`px-2.5 py-1 text-[11px] font-medium rounded ${
                        rule.serveType === 'single'
                          ? 'bg-indigo-600 text-white font-semibold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Single Variation
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        handleUpdateRule(rule.id, {
                          serveType: 'rollout',
                          rolloutDistribution:
                            rule.rolloutDistribution && rule.rolloutDistribution.length > 0
                              ? rule.rolloutDistribution
                              : variations.map((v, i) => ({
                                  variationId: v.id,
                                  percentage: i === 0 ? 100 : 0,
                                })),
                        })
                      }
                      className={`px-2.5 py-1 text-[11px] font-medium rounded ${
                        rule.serveType === 'rollout'
                          ? 'bg-indigo-600 text-white font-semibold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Percentage Rollout Split
                    </button>
                  </div>
                </div>

                {rule.serveType === 'single' ? (
                  <div className="mt-2">
                    <select
                      value={rule.serveVariationId || variations[0]?.id}
                      onChange={(e) => handleUpdateRule(rule.id, { serveVariationId: e.target.value })}
                      disabled={disabled}
                      className="w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-xs font-medium text-slate-100 focus:border-indigo-500 focus:outline-none"
                    >
                      {variations.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.name} ({String(v.value)})
                        </option>
                      ))}
                    </select>
                  </div>
                ) : (
                  <div className="mt-2">
                    <RolloutSlider
                      variations={variations}
                      distribution={rule.rolloutDistribution || []}
                      onChange={(dist) => handleUpdateRule(rule.id, { rolloutDistribution: dist })}
                      disabled={disabled}
                    />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
