import React, { useState } from 'react';
import {
  AlertTriangle,
  Archive,
  Check,
  ChevronRight,
  Copy,
  ExternalLink,
  Flame,
  Layers,
  MoreVertical,
  Plus,
  Search,
  Sliders,
  Trash2,
} from 'lucide-react';
import { useFlags } from '../../context/FlagContext';
import { FeatureFlag, FlagCategory } from '../../types';
import { FlagDetailModal } from './FlagDetailModal';
import { ConfirmKillSwitchModal } from '../shared/ConfirmKillSwitchModal';

interface FlagsListProps {
  onOpenCreateFlag: () => void;
  onOpenPlaygroundForFlag: (flagKey: string) => void;
}

export const FlagsList: React.FC<FlagsListProps> = ({
  onOpenCreateFlag,
  onOpenPlaygroundForFlag,
}) => {
  const { environment, flags, toggleFlag, archiveFlag, deleteFlag } = useFlags();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedFlagForDetail, setSelectedFlagForDetail] = useState<FeatureFlag | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [pendingToggleFlag, setPendingToggleFlag] = useState<FeatureFlag | null>(null);

  const filteredFlags = flags.filter((flag) => {
    const matchesSearch =
      flag.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      flag.key.toLowerCase().includes(searchQuery.toLowerCase()) ||
      flag.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory =
      selectedCategory === 'all' ||
      (selectedCategory === 'archived' && flag.archived) ||
      (!flag.archived && flag.category === selectedCategory);

    return matchesSearch && matchesCategory;
  });

  const handleCopyKey = (key: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(key);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleToggleClick = (flag: FeatureFlag, e: React.MouseEvent) => {
    e.stopPropagation();
    // If in production or if it is a kill switch, show safety prompt
    if (environment === 'production' || flag.category === 'killswitch') {
      setPendingToggleFlag(flag);
    } else {
      toggleFlag(flag.id, environment);
    }
  };

  const categories = [
    { id: 'all', label: 'All Flags' },
    { id: 'release', label: 'Releases' },
    { id: 'experiment', label: 'Experiments' },
    { id: 'killswitch', label: 'Kill Switches' },
    { id: 'operational', label: 'Operational' },
    { id: 'archived', label: 'Archived' },
  ];

  return (
    <div className="space-y-6">
      {/* Search and Filter Bar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search flags by name, key, or tag..."
            className="w-full rounded-lg border border-slate-800 bg-slate-900/80 py-2 pl-9 pr-4 text-xs text-white placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none"
          />
        </div>

        {/* Category Tabs (Interactive Segmented Control) */}
        <div className="flex items-center gap-1 overflow-x-auto rounded-lg border border-slate-800 bg-slate-900/60 p-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`rounded px-3 py-1 text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-slate-800 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Flags List Table */}
      <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/60 shadow-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/40 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              <th className="py-3.5 pl-6 pr-4">Flag Name &amp; Key</th>
              <th className="py-3.5 px-4 hidden md:table-cell">Type &amp; Category</th>
              <th className="py-3.5 px-4">State [{environment}]</th>
              <th className="py-3.5 px-4 hidden lg:table-cell">Targeting Strategy</th>
              <th className="py-3.5 px-4 hidden xl:table-cell">Evaluations</th>
              <th className="py-3.5 pl-4 pr-6 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-xs">
            {filteredFlags.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-slate-400">
                  <div className="flex flex-col items-center justify-center">
                    <Layers className="h-8 w-8 text-slate-600 mb-2" />
                    <p className="font-semibold text-slate-300">No feature flags found</p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Try adjusting your search filter or create a new flag.
                    </p>
                    <button
                      onClick={onOpenCreateFlag}
                      className="mt-4 rounded-md bg-indigo-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500"
                    >
                      Create Feature Flag
                    </button>
                  </div>
                </td>
              </tr>
            ) : (
              filteredFlags.map((flag) => {
                const envConfig = flag.environments[environment];
                const isEnabled = envConfig?.enabled ?? false;
                const rulesCount = envConfig?.rules?.length ?? 0;
                const individualTargetsCount = envConfig?.individualTargets?.reduce(
                  (acc, t) => acc + t.userKeys.length,
                  0
                ) ?? 0;

                const isCanary = envConfig?.canary?.enabled;
                const currentCanaryStage = envConfig?.canary?.stages[envConfig.canary.currentStageIndex];

                return (
                  <tr
                    key={flag.id}
                    onClick={() => setSelectedFlagForDetail(flag)}
                    className="group cursor-pointer transition-colors hover:bg-slate-900/50"
                  >
                    {/* Name & Key */}
                    <td className="py-4 pl-6 pr-4">
                      <div className="flex items-start gap-3">
                        <div
                          className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md border ${
                            flag.category === 'killswitch'
                              ? 'border-rose-500/30 bg-rose-500/10 text-rose-400'
                              : flag.category === 'experiment'
                              ? 'border-purple-500/30 bg-purple-500/10 text-purple-400'
                              : 'border-slate-700 bg-slate-800 text-indigo-400'
                          }`}
                        >
                          <Layers className="h-4 w-4" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-white group-hover:text-indigo-300 transition-colors">
                              {flag.name}
                            </span>
                            {flag.archived && (
                              <span className="text-[10px] text-slate-500 font-mono">
                                [Archived]
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                            <button
                              onClick={(e) => handleCopyKey(flag.key, e)}
                              className="flex items-center gap-1 font-mono text-slate-400 hover:text-white"
                              title="Click to copy key"
                            >
                              <span>{flag.key}</span>
                              {copiedKey === flag.key ? (
                                <Check className="h-3 w-3 text-emerald-400" />
                              ) : (
                                <Copy className="h-3 w-3 opacity-60 hover:opacity-100" />
                              )}
                            </button>
                            <span aria-hidden="true">·</span>
                            <span>{flag.variations.length} variations</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Type & Category */}
                    <td className="py-4 px-4 hidden md:table-cell">
                      <div className="flex flex-col text-xs">
                        <span className="font-medium text-slate-300 capitalize">{flag.type}</span>
                        <div className="flex items-center gap-1 text-[11px] text-slate-500 capitalize">
                          <span>{flag.category}</span>
                          {flag.tags.length > 0 && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="truncate max-w-[120px]">{flag.tags.join(', ')}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Master State Toggle */}
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={(e) => handleToggleClick(flag, e)}
                          disabled={flag.archived}
                          className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none disabled:opacity-40 ${
                            isEnabled ? 'bg-emerald-500' : 'bg-slate-700'
                          }`}
                          title={`Toggle ${flag.name} ${isEnabled ? 'OFF' : 'ON'} in ${environment}`}
                        >
                          <span
                            className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                              isEnabled ? 'translate-x-4' : 'translate-x-0'
                            }`}
                          />
                        </button>
                        <span
                          className={`font-mono text-xs font-bold uppercase ${
                            isEnabled ? 'text-emerald-400' : 'text-slate-500'
                          }`}
                        >
                          {isEnabled ? 'ON' : 'OFF'}
                        </span>
                      </div>
                    </td>

                    {/* Targeting Strategy */}
                    <td className="py-4 px-4 hidden lg:table-cell">
                      <div className="flex flex-col text-xs text-slate-300 space-y-0.5">
                        {isCanary ? (
                          <div className="flex items-center gap-1 text-indigo-400 font-medium">
                            <span className="h-1.5 w-1.5 rounded-full bg-indigo-500 animate-pulse" />
                            <span>Canary Stage {currentCanaryStage?.stage} ({currentCanaryStage?.percentage}%)</span>
                          </div>
                        ) : envConfig.fallthrough.type === 'rollout' ? (
                          <span className="text-purple-300 font-medium">
                            Percentage Rollout ({envConfig.fallthrough.rolloutDistribution?.length} splits)
                          </span>
                        ) : (
                          <span className="text-slate-400">
                            Default: {flag.variations.find((v) => v.id === envConfig.fallthrough.variationId)?.name || 'Variation 1'}
                          </span>
                        )}

                        <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                          {rulesCount > 0 && <span>{rulesCount} custom rule{rulesCount > 1 ? 's' : ''}</span>}
                          {rulesCount > 0 && individualTargetsCount > 0 && <span aria-hidden="true">·</span>}
                          {individualTargetsCount > 0 && (
                            <span>{individualTargetsCount} user target{individualTargetsCount > 1 ? 's' : ''}</span>
                          )}
                          {rulesCount === 0 && individualTargetsCount === 0 && (
                            <span>All users fall through</span>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Evaluations */}
                    <td className="py-4 px-4 hidden xl:table-cell">
                      <div className="font-mono text-xs text-slate-300">
                        {envConfig.evaluationCount.toLocaleString()}
                      </div>
                      <div className="text-[10px] text-slate-500">0.12ms p99</div>
                    </td>

                    {/* Actions */}
                    <td className="py-4 pl-4 pr-6 text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => onOpenPlaygroundForFlag(flag.key)}
                          className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-indigo-400"
                          title="Simulate Evaluation in Playground"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedFlagForDetail(flag)}
                          className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
                          title="Configure Targeting Rules"
                        >
                          <Sliders className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => archiveFlag(flag.id)}
                          className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-amber-400"
                          title={flag.archived ? 'Restore Flag' : 'Archive Flag'}
                        >
                          <Archive className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Flag Detail / Rules Configuration Modal */}
      {selectedFlagForDetail && (
        <FlagDetailModal
          flag={selectedFlagForDetail}
          onClose={() => setSelectedFlagForDetail(null)}
        />
      )}

      {/* Safety Confirmation Guard for Production Toggles */}
      {pendingToggleFlag && (
        <ConfirmKillSwitchModal
          flag={pendingToggleFlag}
          environment={environment}
          onConfirm={() => {
            toggleFlag(pendingToggleFlag.id, environment);
            setPendingToggleFlag(null);
          }}
          onCancel={() => setPendingToggleFlag(null)}
        />
      )}
    </div>
  );
};
