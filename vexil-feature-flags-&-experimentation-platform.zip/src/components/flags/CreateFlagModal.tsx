import React, { useState } from 'react';
import { FlagCategory, FlagVariationType, FeatureFlag, Variation } from '../../types';
import { useFlags } from '../../context/FlagContext';
import { Layers, Plus, X } from 'lucide-react';

interface CreateFlagModalProps {
  onClose: () => void;
}

export const CreateFlagModal: React.FC<CreateFlagModalProps> = ({ onClose }) => {
  const { createFlag } = useFlags();

  const [name, setName] = useState('');
  const [key, setKey] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<FlagVariationType>('boolean');
  const [category, setCategory] = useState<FlagCategory>('release');
  const [tagsInput, setTagsInput] = useState('web, checkout');
  const [maintainer, setMaintainer] = useState('eng-lead@vexil.dev');

  const handleNameChange = (val: string) => {
    setName(val);
    const slug = val
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
    setKey(slug);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !key.trim()) return;

    let initialVariations: Variation[] = [];
    if (type === 'boolean') {
      initialVariations = [
        { id: `var-${Date.now()}-off`, key: 'false', name: 'False (Off)', value: false },
        { id: `var-${Date.now()}-on`, key: 'true', name: 'True (On)', value: true },
      ];
    } else if (type === 'string') {
      initialVariations = [
        { id: `var-${Date.now()}-ctrl`, key: 'control', name: 'Control', value: 'control' },
        { id: `var-${Date.now()}-v1`, key: 'treatment', name: 'Treatment', value: 'treatment' },
      ];
    } else if (type === 'number') {
      initialVariations = [
        { id: `var-${Date.now()}-zero`, key: 'v0', name: 'Default Rate', value: 10 },
        { id: `var-${Date.now()}-boost`, key: 'v1', name: 'Boosted Rate', value: 25 },
      ];
    } else {
      initialVariations = [
        { id: `var-${Date.now()}-off`, key: 'disabled', name: 'Disabled', value: { enabled: false } },
        { id: `var-${Date.now()}-on`, key: 'active', name: 'Active Config', value: { enabled: true, theme: 'indigo' } },
      ];
    }

    const defaultEnvConfig = {
      enabled: false,
      offVariationId: initialVariations[0].id,
      fallthrough: {
        type: 'single' as const,
        variationId: initialVariations[1]?.id || initialVariations[0].id,
      },
      individualTargets: [],
      rules: [],
      evaluationCount: 0,
    };

    const newFlag: FeatureFlag = {
      id: `flag-${Date.now()}`,
      key: key.trim(),
      name: name.trim(),
      description: description.trim(),
      type,
      category,
      tags: tagsInput.split(',').map((t) => t.trim()).filter(Boolean),
      maintainer: maintainer.trim(),
      archived: false,
      variations: initialVariations,
      environments: {
        production: { ...defaultEnvConfig },
        staging: { ...defaultEnvConfig, enabled: true },
        development: { ...defaultEnvConfig, enabled: true },
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    createFlag(newFlag);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="flex w-full max-w-xl flex-col rounded-xl border border-slate-800 bg-slate-950 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white">
              <Layers className="h-4 w-4" />
            </div>
            <h2 className="text-base font-bold text-white">Create New Feature Flag</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleCreate} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Flag Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="e.g. Express One-Click Checkout"
              className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Flag Key (Code Reference)
            </label>
            <input
              type="text"
              required
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="e.g. express-one-click-checkout"
              className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 font-mono text-sm text-indigo-400 focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Purpose of this flag, rollout criteria, hypothesis..."
              className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Variation Type
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as FlagVariationType)}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
              >
                <option value="boolean">Boolean (True / False)</option>
                <option value="string">String (Multivariate Keys)</option>
                <option value="number">Number (Threshold / Value)</option>
                <option value="json">JSON (Dynamic Config Schema)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Flag Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as FlagCategory)}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
              >
                <option value="release">Release (Feature Rollout)</option>
                <option value="experiment">Experiment (A/B Test)</option>
                <option value="killswitch">Kill Switch (Circuit Breaker)</option>
                <option value="operational">Operational (Backend/Infra)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Tags (Comma-separated)
              </label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="e.g. checkout, web, payments"
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Maintainer Email</label>
              <input
                type="email"
                value={maintainer}
                onChange={(e) => setMaintainer(e.target.value)}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-800 pt-4 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-medium text-slate-200 hover:bg-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-5 py-2 text-xs font-semibold text-white shadow-md hover:bg-indigo-500"
            >
              <Plus className="h-4 w-4" />
              <span>Create Flag</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
