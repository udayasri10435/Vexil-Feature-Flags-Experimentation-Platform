import React from 'react';
import { Variation } from '../../types';

interface RolloutSliderProps {
  variations: Variation[];
  distribution: { variationId: string; percentage: number }[];
  onChange: (distribution: { variationId: string; percentage: number }[]) => void;
  disabled?: boolean;
}

const COLORS = [
  'bg-indigo-500',
  'bg-emerald-500',
  'bg-amber-500',
  'bg-purple-500',
  'bg-rose-500',
  'bg-cyan-500',
];

export const RolloutSlider: React.FC<RolloutSliderProps> = ({
  variations,
  distribution,
  onChange,
  disabled = false,
}) => {
  // Ensure every variation has an entry in distribution
  const normalizedDist = variations.map((v) => {
    const existing = distribution.find((d) => d.variationId === v.id);
    return {
      variationId: v.id,
      percentage: existing ? existing.percentage : 0,
    };
  });

  const totalPercentage = Number(
    normalizedDist.reduce((acc, curr) => acc + curr.percentage, 0).toFixed(1)
  );

  const handlePercentageChange = (variationId: string, newPercentage: number) => {
    const clamped = Math.max(0, Math.min(100, Number(newPercentage) || 0));
    const updated = normalizedDist.map((item) =>
      item.variationId === variationId ? { ...item, percentage: clamped } : item
    );
    onChange(updated);
  };

  const handleSplitEqually = () => {
    if (variations.length === 0) return;
    const equalShare = Number((100 / variations.length).toFixed(1));
    const remainder = Number((100 - equalShare * (variations.length - 1)).toFixed(1));

    const updated = variations.map((v, i) => ({
      variationId: v.id,
      percentage: i === 0 ? remainder : equalShare,
    }));
    onChange(updated);
  };

  return (
    <div className="space-y-4 rounded-lg border border-slate-800 bg-slate-900/60 p-4">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
            Progressive Rollout Distribution
          </h4>
          <p className="text-[11px] text-slate-400">
            Deterministically bucket users into variations via 32-bit Murmur3 hash (0% - 100%)
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleSplitEqually}
            disabled={disabled}
            className="text-[11px] font-medium text-indigo-400 hover:text-indigo-300 underline disabled:opacity-50"
          >
            Split Evenly
          </button>
          <span
            className={`font-mono text-xs font-bold ${
              Math.abs(totalPercentage - 100) < 0.1 ? 'text-emerald-400' : 'text-amber-400'
            }`}
          >
            Total: {totalPercentage}% {Math.abs(totalPercentage - 100) >= 0.1 && '(Must sum to 100%)'}
          </span>
        </div>
      </div>

      {/* Visual Bar */}
      <div className="flex h-4 w-full overflow-hidden rounded-md bg-slate-800 p-0.5">
        {normalizedDist.map((dist, idx) => {
          if (dist.percentage <= 0) return null;
          const variation = variations.find((v) => v.id === dist.variationId);
          const colorClass = COLORS[idx % COLORS.length];
          return (
            <div
              key={dist.variationId}
              style={{ width: `${dist.percentage}%` }}
              className={`h-full transition-all duration-300 ${colorClass} first:rounded-l last:rounded-r`}
              title={`${variation?.name || 'Variation'}: ${dist.percentage}%`}
            />
          );
        })}
      </div>

      {/* Variation Inputs */}
      <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
        {normalizedDist.map((dist, idx) => {
          const variation = variations.find((v) => v.id === dist.variationId);
          const colorClass = COLORS[idx % COLORS.length];

          return (
            <div
              key={dist.variationId}
              className="flex items-center justify-between rounded-md border border-slate-800 bg-slate-950/60 px-3 py-2"
            >
              <div className="flex items-center gap-2 overflow-hidden pr-2">
                <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${colorClass}`} />
                <div className="truncate">
                  <div className="truncate text-xs font-semibold text-slate-200">
                    {variation?.name || 'Unknown'}
                  </div>
                  <div className="font-mono text-[10px] text-slate-400 truncate">
                    {variation?.key}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={dist.percentage}
                  onChange={(e) => handlePercentageChange(dist.variationId, parseFloat(e.target.value))}
                  disabled={disabled}
                  className="w-16 rounded border border-slate-700 bg-slate-900 px-2 py-1 text-right font-mono text-xs text-white focus:border-indigo-500 focus:outline-none"
                />
                <span className="text-xs text-slate-400">%</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
