import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Check,
  Code2,
  Copy,
  Layers,
  Plus,
  Save,
  Sliders,
  Trash2,
  UserCheck,
  X,
  Zap,
} from 'lucide-react';
import { useFlags } from '../../context/FlagContext';
import { Environment, FeatureFlag, Variation } from '../../types';
import { TargetingRulesEditor } from './TargetingRulesEditor';
import { RolloutSlider } from './RolloutSlider';

interface FlagDetailModalProps {
  flag: FeatureFlag;
  onClose: () => void;
}

export const FlagDetailModal: React.FC<FlagDetailModalProps> = ({ flag: initialFlag, onClose }) => {
  const { environment, updateFlag, segments } = useFlags();
  const [selectedEnv, setSelectedEnv] = useState<Environment>(environment);
  const [activeTab, setActiveTab] = useState<'rules' | 'variations' | 'canary' | 'sdk' | 'telemetry'>('rules');

  const [flag, setFlag] = useState<FeatureFlag>(JSON.parse(JSON.stringify(initialFlag)));
  const [hasChanges, setHasChanges] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedSnippet, setCopiedSnippet] = useState(false);
  const [newTargetUserKey, setNewTargetUserKey] = useState('');
  const [selectedTargetVarId, setSelectedTargetVarId] = useState(flag.variations[0]?.id || '');
  const [jsonError, setJsonError] = useState<string | null>(null);

  const envConfig = flag.environments[selectedEnv];

  const handleCopyKey = () => {
    navigator.clipboard.writeText(flag.key);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleEnvToggle = () => {
    setFlag((prev) => ({
      ...prev,
      environments: {
        ...prev.environments,
        [selectedEnv]: {
          ...prev.environments[selectedEnv],
          enabled: !prev.environments[selectedEnv].enabled,
        },
      },
    }));
    setHasChanges(true);
  };

  const handleUpdateEnvConfig = (partial: Partial<typeof envConfig>) => {
    setFlag((prev) => ({
      ...prev,
      environments: {
        ...prev.environments,
        [selectedEnv]: {
          ...prev.environments[selectedEnv],
          ...partial,
        },
      },
    }));
    setHasChanges(true);
  };

  const handleAddIndividualTarget = () => {
    if (!newTargetUserKey.trim()) return;
    const currentTargets = envConfig.individualTargets || [];
    const existingIndex = currentTargets.findIndex((t) => t.variationId === selectedTargetVarId);

    let nextTargets = [...currentTargets];
    if (existingIndex >= 0) {
      if (!nextTargets[existingIndex].userKeys.includes(newTargetUserKey.trim())) {
        nextTargets[existingIndex].userKeys.push(newTargetUserKey.trim());
      }
    } else {
      nextTargets.push({
        variationId: selectedTargetVarId,
        userKeys: [newTargetUserKey.trim()],
      });
    }

    handleUpdateEnvConfig({ individualTargets: nextTargets });
    setNewTargetUserKey('');
  };

  const handleRemoveIndividualTarget = (variationId: string, userKey: string) => {
    const nextTargets = envConfig.individualTargets
      .map((t) => {
        if (t.variationId !== variationId) return t;
        return {
          ...t,
          userKeys: t.userKeys.filter((k) => k !== userKey),
        };
      })
      .filter((t) => t.userKeys.length > 0);

    handleUpdateEnvConfig({ individualTargets: nextTargets });
  };

  const handleSave = () => {
    if (jsonError) return;
    updateFlag(flag, `Saved configuration changes for flag ${flag.key} in [${selectedEnv}]`);
    setHasChanges(false);
    onClose();
  };

  const getCodeSnippet = (lang: string) => {
    const isBool = flag.type === 'boolean';
    const returnType = isBool ? 'boolean' : flag.type === 'json' ? 'object' : 'string';

    switch (lang) {
      case 'react':
        return `import { useFeatureFlag } from '@vexil/react-sdk';

export function FeatureComponent() {
  const { value, isEnabled, loading } = useFeatureFlag('${flag.key}', {
    defaultValue: ${JSON.stringify(flag.variations[0]?.value)},
  });

  if (loading) return <Spinner />;

  return isEnabled ? (
    <NewExperience config={value} />
  ) : (
    <LegacyExperience />
  );
}`;
      case 'node':
        return `import { VexilClient } from '@vexil/node-sdk';

const vexil = new VexilClient({
  sdkKey: process.env.VEXIL_SDK_KEY,
  environment: '${selectedEnv}',
});

// Evaluate in Express route / microservice
app.get('/api/resource', async (req, res) => {
  const user = {
    key: req.user.id,
    email: req.user.email,
    plan: req.user.subscriptionPlan,
  };

  const flagValue = await vexil.evaluate('${flag.key}', user, {
    defaultValue: ${JSON.stringify(flag.variations[0]?.value)},
  });

  res.json({ data: flagValue });
});`;
      case 'python':
        return `from vexil_sdk import VexilClient, UserContext

client = VexilClient(sdk_key="vexil_live_secret", env="${selectedEnv}")

user = UserContext(
    key="user-4402",
    email="analyst@acme.com",
    plan="enterprise"
)

result = client.evaluate(
    flag_key="${flag.key}",
    user=user,
    default=${JSON.stringify(flag.variations[0]?.value)}
)

print(f"Served variation: {result.variation_name} -> {result.value}")`;
      case 'curl':
        return `curl -X POST https://api.vexil.dev/v1/flags/${flag.key}/evaluate \\
  -H "Authorization: Bearer vexil_live_sdk_key" \\
  -H "Content-Type: application/json" \\
  -d '{
    "environment": "${selectedEnv}",
    "user": {
      "key": "user-8812",
      "email": "user@acme.com",
      "plan": "enterprise"
    }
  }'`;
      default:
        return '';
    }
  };

  const [selectedLang, setSelectedLang] = useState<'react' | 'node' | 'python' | 'curl'>('react');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="flex h-[92vh] w-full max-w-5xl flex-col rounded-xl border border-slate-800 bg-slate-950 shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-900/60">
          <div className="flex items-center gap-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-700 bg-slate-800 text-indigo-400">
              <Layers className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-base font-bold text-white">{flag.name}</h2>
                <button
                  onClick={handleCopyKey}
                  className="flex items-center gap-1 rounded bg-slate-800 px-2 py-0.5 font-mono text-xs text-slate-300 hover:bg-slate-700 hover:text-white"
                  title="Copy flag key"
                >
                  <span>{flag.key}</span>
                  {copiedKey ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                </button>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                <span className="capitalize">{flag.type} Flag</span>
                <span aria-hidden="true">·</span>
                <span className="capitalize">{flag.category}</span>
                <span aria-hidden="true">·</span>
                <span>Maintainer: {flag.maintainer}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Environment Selector within modal */}
            <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900 p-1">
              {(['production', 'staging', 'development'] as Environment[]).map((env) => (
                <button
                  key={env}
                  onClick={() => setSelectedEnv(env)}
                  className={`rounded px-2.5 py-1 text-xs font-semibold capitalize transition-colors ${
                    selectedEnv === env
                      ? 'bg-slate-800 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {env}
                </button>
              ))}
            </div>

            {/* Master Toggle */}
            <div className="flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-900 px-3 py-1.5">
              <span className="text-xs text-slate-400 font-medium">State:</span>
              <button
                type="button"
                onClick={handleEnvToggle}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  envConfig.enabled ? 'bg-emerald-500' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    envConfig.enabled ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
              <span
                className={`font-mono text-xs font-bold uppercase ${
                  envConfig.enabled ? 'text-emerald-400' : 'text-slate-400'
                }`}
              >
                {envConfig.enabled ? 'ON' : 'OFF'}
              </span>
            </div>

            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950 px-6">
          <button
            onClick={() => setActiveTab('rules')}
            className={`border-b-2 py-3 px-4 text-xs font-semibold transition-colors ${
              activeTab === 'rules'
                ? 'border-indigo-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Targeting &amp; Rules
          </button>
          <button
            onClick={() => setActiveTab('variations')}
            className={`border-b-2 py-3 px-4 text-xs font-semibold transition-colors ${
              activeTab === 'variations'
                ? 'border-indigo-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Variations ({flag.variations.length})
          </button>
          <button
            onClick={() => setActiveTab('canary')}
            className={`border-b-2 py-3 px-4 text-xs font-semibold transition-colors ${
              activeTab === 'canary'
                ? 'border-indigo-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Canary Strategy
          </button>
          <button
            onClick={() => setActiveTab('sdk')}
            className={`border-b-2 py-3 px-4 text-xs font-semibold transition-colors ${
              activeTab === 'sdk'
                ? 'border-indigo-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            SDK Code Snippets
          </button>
          <button
            onClick={() => setActiveTab('telemetry')}
            className={`border-b-2 py-3 px-4 text-xs font-semibold transition-colors ${
              activeTab === 'telemetry'
                ? 'border-indigo-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Telemetry &amp; Health
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: RULES & TARGETING */}
          {activeTab === 'rules' && (
            <div className="space-y-6">
              {/* OFF variation serving setting */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between rounded-lg border border-slate-800 bg-slate-900/50 p-4">
                <div>
                  <div className="text-xs font-semibold text-slate-200">
                    When Flag is OFF in [{selectedEnv}]:
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Specify the baseline fallback served when the master toggle is disabled or killed.
                  </div>
                </div>
                <div className="mt-2 sm:mt-0">
                  <select
                    value={envConfig.offVariationId}
                    onChange={(e) => handleUpdateEnvConfig({ offVariationId: e.target.value })}
                    className="rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white focus:border-indigo-500 focus:outline-none"
                  >
                    {flag.variations.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({String(v.value)})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Individual User Target Overrides */}
              <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                      Individual User Overrides (Whitelist)
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Explicitly force variations for VIP accounts, demo keys, or test engineers.
                    </p>
                  </div>
                  <UserCheck className="h-4 w-4 text-indigo-400" />
                </div>

                <div className="flex flex-wrap gap-2">
                  <input
                    type="text"
                    value={newTargetUserKey}
                    onChange={(e) => setNewTargetUserKey(e.target.value)}
                    placeholder="User key or email (e.g. alice@acme.com)"
                    className="flex-1 min-w-[200px] rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none"
                  />
                  <select
                    value={selectedTargetVarId}
                    onChange={(e) => setSelectedTargetVarId(e.target.value)}
                    className="rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white focus:border-indigo-500 focus:outline-none"
                  >
                    {flag.variations.map((v) => (
                      <option key={v.id} value={v.id}>
                        Serve: {v.name}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={handleAddIndividualTarget}
                    className="flex items-center gap-1 rounded bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>Add Target</span>
                  </button>
                </div>

                {envConfig.individualTargets && envConfig.individualTargets.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {envConfig.individualTargets.map((target) => {
                      const v = flag.variations.find((varItem) => varItem.id === target.variationId);
                      return (
                        <div
                          key={target.variationId}
                          className="flex flex-col gap-1.5 rounded border border-slate-800 bg-slate-950/70 p-2.5"
                        >
                          <div className="text-[11px] font-semibold text-indigo-300">
                            Serving: {v?.name}
                          </div>
                          <div className="flex flex-wrap gap-1.5">
                            {target.userKeys.map((key) => (
                              <span
                                key={key}
                                className="flex items-center gap-1 rounded bg-slate-800 px-2 py-0.5 font-mono text-[11px] text-slate-300"
                              >
                                <span>{key}</span>
                                <button
                                  type="button"
                                  onClick={() => handleRemoveIndividualTarget(target.variationId, key)}
                                  className="text-slate-500 hover:text-rose-400"
                                >
                                  ×
                                </button>
                              </span>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Targeting Rules Editor */}
              <TargetingRulesEditor
                rules={envConfig.rules}
                variations={flag.variations}
                segments={segments}
                onChange={(updatedRules) => handleUpdateEnvConfig({ rules: updatedRules })}
              />

              {/* Default Fallthrough Strategy */}
              <div className="space-y-3 rounded-lg border border-slate-800 bg-slate-900/60 p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                      Default Fallthrough Rule
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Applies to all remaining traffic that didn't match individual targets or custom rules above.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        handleUpdateEnvConfig({
                          fallthrough: {
                            type: 'single',
                            variationId: flag.variations[0]?.id,
                          },
                        })
                      }
                      className={`px-2.5 py-1 text-xs font-medium rounded ${
                        envConfig.fallthrough.type === 'single'
                          ? 'bg-indigo-600 text-white font-semibold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Single Variation
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        handleUpdateEnvConfig({
                          fallthrough: {
                            type: 'rollout',
                            rolloutDistribution: flag.variations.map((v, i) => ({
                              variationId: v.id,
                              percentage: i === 0 ? 100 : 0,
                            })),
                          },
                        })
                      }
                      className={`px-2.5 py-1 text-xs font-medium rounded ${
                        envConfig.fallthrough.type === 'rollout'
                          ? 'bg-indigo-600 text-white font-semibold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Progressive Rollout Split
                    </button>
                  </div>
                </div>

                {envConfig.fallthrough.type === 'single' ? (
                  <select
                    value={envConfig.fallthrough.variationId || flag.variations[0]?.id}
                    onChange={(e) =>
                      handleUpdateEnvConfig({
                        fallthrough: {
                          type: 'single',
                          variationId: e.target.value,
                        },
                      })
                    }
                    className="w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-xs font-medium text-slate-200 focus:border-indigo-500 focus:outline-none"
                  >
                    {flag.variations.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({String(v.value)})
                      </option>
                    ))}
                  </select>
                ) : (
                  <RolloutSlider
                    variations={flag.variations}
                    distribution={envConfig.fallthrough.rolloutDistribution || []}
                    onChange={(dist) =>
                      handleUpdateEnvConfig({
                        fallthrough: {
                          type: 'rollout',
                          rolloutDistribution: dist,
                        },
                      })
                    }
                  />
                )}
              </div>
            </div>
          )}

          {/* TAB 2: VARIATIONS */}
          {activeTab === 'variations' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-slate-200">Flag Variations</h3>
                  <p className="text-xs text-slate-400">
                    Values served by this feature flag across codebases.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const newVar: Variation = {
                      id: `var-${Date.now()}`,
                      key: `variation-${flag.variations.length + 1}`,
                      name: `Variation ${flag.variations.length + 1}`,
                      value: flag.type === 'boolean' ? false : flag.type === 'number' ? 0 : '',
                      description: 'Custom variation',
                    };
                    setFlag((prev) => ({
                      ...prev,
                      variations: [...prev.variations, newVar],
                    }));
                    setHasChanges(true);
                  }}
                  className="flex items-center gap-1.5 rounded bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Add Variation</span>
                </button>
              </div>

              <div className="space-y-3">
                {flag.variations.map((v, idx) => (
                  <div key={v.id} className="rounded-lg border border-slate-800 bg-slate-900/70 p-4 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-indigo-400">#{idx + 1}</span>
                        <input
                          type="text"
                          value={v.name}
                          onChange={(e) => {
                            const newVars = [...flag.variations];
                            newVars[idx].name = e.target.value;
                            setFlag({ ...flag, variations: newVars });
                            setHasChanges(true);
                          }}
                          className="border-b border-transparent bg-transparent px-1 py-0.5 text-xs font-bold text-white focus:border-indigo-500 focus:outline-none"
                        />
                      </div>
                      {flag.variations.length > 2 && (
                        <button
                          type="button"
                          onClick={() => {
                            const newVars = flag.variations.filter((item) => item.id !== v.id);
                            setFlag({ ...flag, variations: newVars });
                            setHasChanges(true);
                          }}
                          className="text-slate-500 hover:text-rose-400"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
                          Variation Key
                        </label>
                        <input
                          type="text"
                          value={v.key}
                          onChange={(e) => {
                            const newVars = [...flag.variations];
                            newVars[idx].key = e.target.value;
                            setFlag({ ...flag, variations: newVars });
                            setHasChanges(true);
                          }}
                          className="w-full rounded border border-slate-700 bg-slate-950 px-2.5 py-1.5 font-mono text-xs text-white focus:border-indigo-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
                          Served Value ({flag.type})
                        </label>
                        {flag.type === 'boolean' ? (
                          <select
                            value={String(v.value)}
                            onChange={(e) => {
                              const newVars = [...flag.variations];
                              newVars[idx].value = e.target.value === 'true';
                              setFlag({ ...flag, variations: newVars });
                              setHasChanges(true);
                            }}
                            className="w-full rounded border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-xs text-white focus:border-indigo-500 focus:outline-none"
                          >
                            <option value="true">true</option>
                            <option value="false">false</option>
                          </select>
                        ) : flag.type === 'json' ? (
                          <div>
                            <textarea
                              rows={4}
                              value={
                                typeof v.value === 'object'
                                  ? JSON.stringify(v.value, null, 2)
                                  : String(v.value)
                              }
                              onChange={(e) => {
                                try {
                                  const parsed = JSON.parse(e.target.value);
                                  const newVars = [...flag.variations];
                                  newVars[idx].value = parsed;
                                  setFlag({ ...flag, variations: newVars });
                                  setJsonError(null);
                                  setHasChanges(true);
                                } catch (err: any) {
                                  setJsonError(err.message);
                                }
                              }}
                              className="w-full rounded border border-slate-700 bg-slate-950 p-2 font-mono text-xs text-emerald-400 focus:border-indigo-500 focus:outline-none"
                            />
                            {jsonError && <p className="text-[11px] text-rose-400 mt-1">{jsonError}</p>}
                          </div>
                        ) : (
                          <input
                            type={flag.type === 'number' ? 'number' : 'text'}
                            value={String(v.value)}
                            onChange={(e) => {
                              const newVars = [...flag.variations];
                              newVars[idx].value =
                                flag.type === 'number' ? parseFloat(e.target.value) || 0 : e.target.value;
                              setFlag({ ...flag, variations: newVars });
                              setHasChanges(true);
                            }}
                            className="w-full rounded border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-xs text-white focus:border-indigo-500 focus:outline-none"
                          />
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: CANARY STRATEGY */}
          {activeTab === 'canary' && (
            <div className="space-y-6">
              <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Activity className="h-6 w-6 text-indigo-400" />
                    <div>
                      <h4 className="text-sm font-semibold text-white">
                        Automated Progressive Canary Release
                      </h4>
                      <p className="text-xs text-slate-400">
                        Roll out changes safely in stages (e.g., 5% → 25% → 50% → 100%) with error rate circuit breakers.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const currentCanary = envConfig.canary;
                      handleUpdateEnvConfig({
                        canary: currentCanary
                          ? { ...currentCanary, enabled: !currentCanary.enabled }
                          : {
                              enabled: true,
                              currentStageIndex: 0,
                              maxErrorRateThreshold: 1.0,
                              autoPromote: false,
                              circuitBreakerTripped: false,
                              stages: [
                                { stage: 1, percentage: 5, label: 'Canary Stage 1 (5%)', status: 'active', errorRatePercent: 0.05, latencyP99Ms: 4.1 },
                                { stage: 2, percentage: 25, label: 'Canary Stage 2 (25%)', status: 'pending', errorRatePercent: 0.0, latencyP99Ms: 0.0 },
                                { stage: 3, percentage: 50, label: 'Canary Stage 3 (50%)', status: 'pending', errorRatePercent: 0.0, latencyP99Ms: 0.0 },
                                { stage: 4, percentage: 100, label: 'Full Production (100%)', status: 'pending', errorRatePercent: 0.0, latencyP99Ms: 0.0 },
                              ],
                            },
                      });
                    }}
                    className={`rounded px-3 py-1.5 text-xs font-semibold uppercase tracking-wider ${
                      envConfig.canary?.enabled
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    {envConfig.canary?.enabled ? 'Canary Active' : 'Enable Canary Pipeline'}
                  </button>
                </div>

                {envConfig.canary?.enabled && (
                  <div className="space-y-4 pt-2">
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
                      {envConfig.canary.stages.map((st, i) => (
                        <div
                          key={st.stage}
                          className={`rounded-lg border p-3 ${
                            st.status === 'active'
                              ? 'border-indigo-500 bg-indigo-950/30'
                              : st.status === 'passed'
                              ? 'border-emerald-500/40 bg-emerald-950/20'
                              : 'border-slate-800 bg-slate-900/40'
                          }`}
                        >
                          <div className="flex items-center justify-between text-xs font-bold">
                            <span className="text-white">Stage {st.stage}</span>
                            <span className="font-mono text-indigo-400">{st.percentage}%</span>
                          </div>
                          <div className="mt-1 text-[11px] text-slate-400 capitalize">
                            Status: <span className="font-medium text-slate-200">{st.status}</span>
                          </div>
                          <div className="mt-2 text-[10px] text-slate-500 font-mono">
                            Err: {st.errorRatePercent}% · Latency: {st.latencyP99Ms}ms
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center justify-between border-t border-slate-800 pt-3 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400">Max Tolerable Error Rate:</span>
                        <span className="font-mono font-bold text-white">
                          {envConfig.canary.maxErrorRateThreshold}%
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400">Circuit Breaker:</span>
                        <span
                          className={`font-semibold ${
                            envConfig.canary.circuitBreakerTripped
                              ? 'text-rose-400'
                              : 'text-emerald-400'
                          }`}
                        >
                          {envConfig.canary.circuitBreakerTripped ? 'TRIPPED (ROLLED BACK)' : 'HEALTHY'}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: SDK INTEGRATION */}
          {activeTab === 'sdk' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-slate-200">SDK Implementation Guide</h3>
                  <p className="text-xs text-slate-400">
                    Production client and server code examples for flag "{flag.key}".
                  </p>
                </div>
                <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900 p-1">
                  {(['react', 'node', 'python', 'curl'] as const).map((lang) => (
                    <button
                      key={lang}
                      onClick={() => setSelectedLang(lang)}
                      className={`rounded px-2.5 py-1 text-xs font-mono uppercase transition-colors ${
                        selectedLang === lang
                          ? 'bg-indigo-600 text-white font-semibold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {lang}
                    </button>
                  ))}
                </div>
              </div>

              <div className="relative rounded-lg border border-slate-800 bg-slate-950 p-4">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(getCodeSnippet(selectedLang));
                    setCopiedSnippet(true);
                    setTimeout(() => setCopiedSnippet(false), 2000);
                  }}
                  className="absolute top-3 right-3 flex items-center gap-1 rounded bg-slate-800 px-2.5 py-1 text-xs text-slate-300 hover:bg-slate-700 hover:text-white"
                >
                  {copiedSnippet ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copiedSnippet ? 'Copied!' : 'Copy Code'}</span>
                </button>
                <pre className="overflow-x-auto text-xs font-mono text-indigo-300 leading-relaxed">
                  <code>{getCodeSnippet(selectedLang)}</code>
                </pre>
              </div>
            </div>
          )}

          {/* TAB 5: TELEMETRY & HEALTH */}
          {activeTab === 'telemetry' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4">
                  <div className="text-xs font-medium text-slate-400">30-Day Evaluations</div>
                  <div className="mt-1 font-mono text-2xl font-bold text-white">
                    {envConfig.evaluationCount.toLocaleString()}
                  </div>
                  <div className="mt-1 text-[11px] text-emerald-400">↑ 18.4% from previous month</div>
                </div>

                <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4">
                  <div className="text-xs font-medium text-slate-400">Evaluator P99 Latency</div>
                  <div className="mt-1 font-mono text-2xl font-bold text-white">0.12 ms</div>
                  <div className="mt-1 text-[11px] text-slate-400">Zero network hop (Local cache)</div>
                </div>

                <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4">
                  <div className="text-xs font-medium text-slate-400">Cache Hit Rate</div>
                  <div className="mt-1 font-mono text-2xl font-bold text-emerald-400">99.98%</div>
                  <div className="mt-1 text-[11px] text-slate-400">SSE Edge streaming synced</div>
                </div>
              </div>

              <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4 space-y-2">
                <div className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                  Targeting Health &amp; Evaluation Distribution
                </div>
                <p className="text-xs text-slate-400">
                  Real-time breakdown of which rules and variations users are receiving in [{selectedEnv}].
                </p>
                <div className="pt-2 space-y-2">
                  {flag.variations.map((v, i) => (
                    <div key={v.id} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-semibold text-slate-300">{v.name}</span>
                        <span className="font-mono text-slate-400">
                          {i === 0 ? '62.4%' : i === 1 ? '28.1%' : '9.5%'}
                        </span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-indigo-500 rounded-full"
                          style={{ width: i === 0 ? '62.4%' : i === 1 ? '28.1%' : '9.5%' }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-slate-800 px-6 py-4 bg-slate-900/60">
          <div className="text-xs text-slate-400">
            {hasChanges ? (
              <span className="flex items-center gap-1.5 text-amber-400 font-medium">
                <AlertTriangle className="h-4 w-4" />
                Unsaved changes in [{selectedEnv}]
              </span>
            ) : (
              <span>All changes synced</span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-medium text-slate-200 hover:bg-slate-700"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={!hasChanges || !!jsonError}
              className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-5 py-2 text-xs font-semibold text-white shadow-md hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Save className="h-4 w-4" />
              <span>Save &amp; Publish</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
