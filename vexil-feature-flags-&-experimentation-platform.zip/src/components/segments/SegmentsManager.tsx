import React, { useState } from 'react';
import { Plus, Trash2, Users2, X, Check, ShieldCheck } from 'lucide-react';
import { useFlags } from '../../context/FlagContext';
import { RuleOperator, Segment } from '../../types';

export const SegmentsManager: React.FC = () => {
  const { segments, createSegment, updateSegment, deleteSegment } = useFlags();

  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [key, setKey] = useState('');
  const [description, setDescription] = useState('');
  const [attribute, setAttribute] = useState('plan');
  const [operator, setOperator] = useState<RuleOperator>('equals');
  const [valuesInput, setValuesInput] = useState('enterprise');
  const [includedUsers, setIncludedUsers] = useState('');

  const handleNameChange = (val: string) => {
    setName(val);
    const slug = `seg-${val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')}`;
    setKey(slug);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !key) return;

    const newSeg: Segment = {
      id: `seg-${Date.now()}`,
      key: key.trim(),
      name: name.trim(),
      description: description.trim(),
      rules: [
        {
          attribute,
          operator,
          values: valuesInput.split(',').map((v) => v.trim()).filter(Boolean),
        },
      ],
      includedUserKeys: includedUsers.split(',').map((v) => v.trim()).filter(Boolean),
      excludedUserKeys: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    createSegment(newSeg);
    setCreateModalOpen(false);
    setName('');
    setKey('');
    setDescription('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <Users2 className="h-4 w-4" />
            </div>
            <h2 className="text-base font-bold text-white">Reusable User Segments</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Build standardized cohorts (e.g. VIP customers, Beta testers, internal employees) to reuse across flags and experiments.
          </p>
        </div>

        <button
          onClick={() => setCreateModalOpen(true)}
          className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500"
        >
          <Plus className="h-4 w-4" />
          <span>New Segment</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {segments.map((seg) => (
          <div
            key={seg.id}
            className="rounded-xl border border-slate-800 bg-slate-950/70 p-5 shadow-lg space-y-3"
          >
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">{seg.name}</h3>
                <span className="font-mono text-[11px] text-slate-500">{seg.key}</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (confirm(`Delete segment "${seg.name}"?`)) {
                    deleteSegment(seg.id);
                  }
                }}
                className="text-slate-500 hover:text-rose-400 p-1"
                title="Delete Segment"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 line-clamp-2">{seg.description}</p>

            <div className="space-y-1.5 border-t border-slate-800/80 pt-3 text-xs">
              <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Rules &amp; Criteria:</div>
              {seg.rules.map((r, i) => (
                <div key={i} className="font-mono text-[11px] text-indigo-300 bg-slate-900/80 rounded px-2 py-1">
                  {r.attribute} {r.operator} [{r.values.join(', ')}]
                </div>
              ))}

              {seg.includedUserKeys.length > 0 && (
                <div className="text-[11px] text-slate-400 pt-1">
                  +{seg.includedUserKeys.length} explicit user overrides
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-xl border border-slate-800 bg-slate-950 p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Create Reusable Segment</h3>
              <button onClick={() => setCreateModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Segment Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  placeholder="e.g. Enterprise VIPs"
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Key</label>
                <input
                  type="text"
                  required
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  placeholder="seg-enterprise-vips"
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 font-mono text-xs text-indigo-400 focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe who belongs in this segment..."
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">Attribute</label>
                  <input
                    type="text"
                    value={attribute}
                    onChange={(e) => setAttribute(e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">Operator</label>
                  <select
                    value={operator}
                    onChange={(e) => setOperator(e.target.value as RuleOperator)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-white"
                  >
                    <option value="equals">equals</option>
                    <option value="contains">contains</option>
                    <option value="ends_with">ends with</option>
                    <option value="in_list">in list</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">Values</label>
                  <input
                    type="text"
                    value={valuesInput}
                    onChange={(e) => setValuesInput(e.target.value)}
                    placeholder="enterprise, pro"
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Direct Whitelisted Users (Optional)
                </label>
                <input
                  type="text"
                  value={includedUsers}
                  onChange={(e) => setIncludedUsers(e.target.value)}
                  placeholder="user-1, user-2 (comma separated)"
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="rounded-lg border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-indigo-600 px-5 py-2 text-xs font-semibold text-white hover:bg-indigo-500"
                >
                  Save Segment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
