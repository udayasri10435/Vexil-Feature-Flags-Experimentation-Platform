import React, { useState } from 'react';
import { FileClock, Search, ShieldCheck, User } from 'lucide-react';
import { useFlags } from '../../context/FlagContext';

export const AuditLogsView: React.FC = () => {
  const { auditLogs } = useFlags();
  const [search, setSearch] = useState('');

  const filteredLogs = auditLogs.filter(
    (log) =>
      log.summary.toLowerCase().includes(search.toLowerCase()) ||
      log.actor.name.toLowerCase().includes(search.toLowerCase()) ||
      log.entityKey.toLowerCase().includes(search.toLowerCase()) ||
      log.action.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <FileClock className="h-4 w-4" />
            </div>
            <h2 className="text-base font-bold text-white">Audit Log &amp; Governance Trail</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Immutable, cryptographically verifiable log of all configuration adjustments, toggles, rollouts, and incident responses.
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by actor, flag key, or action..."
            className="w-full rounded-lg border border-slate-800 bg-slate-900 py-1.5 pl-9 pr-3 text-xs text-white placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none"
          />
        </div>
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/70 shadow-xl">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/40 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              <th className="py-3 px-6">Timestamp</th>
              <th className="py-3 px-4">Actor</th>
              <th className="py-3 px-4">Action</th>
              <th className="py-3 px-4">Target Entity</th>
              <th className="py-3 px-6">Change Summary</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredLogs.map((log) => {
              const isKillSwitch = log.action === 'KILL_SWITCH_TRIPPED';
              const isCanary = log.action.startsWith('CANARY_');

              return (
                <tr key={log.id} className="hover:bg-slate-900/40 transition-colors">
                  {/* Timestamp */}
                  <td className="py-3.5 px-6 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleString()}
                  </td>

                  {/* Actor */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-800 text-[10px] font-bold text-slate-300">
                        {log.actor.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-semibold text-white">{log.actor.name}</div>
                        <div className="text-[10px] text-slate-500">{log.actor.role}</div>
                      </div>
                    </div>
                  </td>

                  {/* Action Badge */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span
                      className={`font-mono text-[10px] font-bold px-2 py-0.5 rounded ${
                        isKillSwitch
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                          : isCanary
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                          : log.action.includes('TOGGLE')
                          ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {log.action}
                    </span>
                  </td>

                  {/* Entity */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <div className="font-medium text-slate-200">{log.entityName}</div>
                    <div className="font-mono text-[10px] text-slate-500">{log.entityKey}</div>
                  </td>

                  {/* Summary */}
                  <td className="py-3.5 px-6 text-slate-300">
                    <div>{log.summary}</div>
                    {log.diff && log.diff.length > 0 && (
                      <div className="mt-1 flex flex-wrap gap-2 text-[10px] font-mono text-slate-500">
                        {log.diff.map((d, i) => (
                          <span key={i} className="bg-slate-900 px-1.5 py-0.5 rounded">
                            {d.field}: {String(d.oldValue)} → {String(d.newValue)}
                          </span>
                        ))}
                      </div>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
