import React, { useState } from 'react';
import {
  Boxes,
  Check,
  ChevronDown,
  Download,
  Flame,
  Globe,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  Upload,
  User,
} from 'lucide-react';
import { useFlags } from '../context/FlagContext';
import { Environment } from '../types';
import { SAMPLE_USER_CONTEXTS } from '../data/initialData';

interface HeaderProps {
  onOpenCreateFlag: () => void;
  onOpenCreateExp: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCreateFlag,
  onOpenCreateExp,
  activeTab,
  setActiveTab,
}) => {
  const {
    environment,
    setEnvironment,
    currentUserContext,
    setCurrentUserContext,
    resetToSampleData,
    exportStateJson,
    importStateJson,
  } = useFlags();

  const [showEnvDropdown, setShowEnvDropdown] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [showMoreActions, setShowMoreActions] = useState(false);
  const [copiedExport, setCopiedExport] = useState(false);

  const envColors: Record<Environment, { text: string; bg: string; dot: string; border: string }> = {
    production: {
      text: 'text-rose-400',
      bg: 'bg-rose-500/10',
      dot: 'bg-rose-500',
      border: 'border-rose-500/30',
    },
    staging: {
      text: 'text-amber-400',
      bg: 'bg-amber-500/10',
      dot: 'bg-amber-500',
      border: 'border-amber-500/30',
    },
    development: {
      text: 'text-emerald-400',
      bg: 'bg-emerald-500/10',
      dot: 'bg-emerald-500',
      border: 'border-emerald-500/30',
    },
  };

  const currentEnvStyle = envColors[environment];

  const handleExport = () => {
    const json = exportStateJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vexil-flags-export-${environment}-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setCopiedExport(true);
    setTimeout(() => setCopiedExport(false), 2000);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const ok = importStateJson(content);
        if (ok) {
          setShowMoreActions(false);
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      <div className="flex h-16 items-center justify-between px-4 lg:px-8">
        {/* Brand & Environment selector */}
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 text-white shadow-lg shadow-indigo-500/20">
              <Boxes className="h-5 w-5" />
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-base font-bold tracking-tight text-white">VEXIL</span>
                <span className="text-[11px] font-medium uppercase tracking-wider text-indigo-400">ENGINE</span>
              </div>
              <span className="text-[11px] text-slate-400">Feature Flags &amp; Experimentation</span>
            </div>
          </div>

          {/* Environment Switcher */}
          <div className="relative">
            <button
              onClick={() => setShowEnvDropdown(!showEnvDropdown)}
              className={`flex items-center gap-2 rounded-md border px-3 py-1.5 text-xs font-semibold uppercase tracking-wider transition-all hover:bg-slate-900 ${currentEnvStyle.border} ${currentEnvStyle.bg} ${currentEnvStyle.text}`}
            >
              <span className={`h-2 w-2 rounded-full animate-pulse ${currentEnvStyle.dot}`} />
              <span>{environment}</span>
              <ChevronDown className="h-3.5 w-3.5 opacity-70" />
            </button>

            {showEnvDropdown && (
              <div className="absolute left-0 mt-2 w-48 rounded-lg border border-slate-800 bg-slate-900 p-1 shadow-2xl z-50">
                <div className="px-2 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Target Environment
                </div>
                {(['production', 'staging', 'development'] as Environment[]).map((env) => (
                  <button
                    key={env}
                    onClick={() => {
                      setEnvironment(env);
                      setShowEnvDropdown(false);
                    }}
                    className={`flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-xs font-medium capitalize transition-colors ${
                      environment === env
                        ? 'bg-slate-800 text-white'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${envColors[env].dot}`} />
                      <span>{env}</span>
                    </div>
                    {environment === env && <Check className="h-3.5 w-3.5 text-indigo-400" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Center / Right controls */}
        <div className="flex items-center gap-3">
          {/* User Evaluation Context Selector */}
          <div className="relative hidden md:block">
            <button
              onClick={() => setShowUserDropdown(!showUserDropdown)}
              className="flex items-center gap-2 rounded-md border border-slate-800 bg-slate-900/80 px-3 py-1.5 text-xs text-slate-300 transition-colors hover:border-slate-700 hover:text-white"
            >
              <User className="h-3.5 w-3.5 text-slate-400" />
              <div className="flex items-center gap-1.5 max-w-[160px] truncate">
                <span className="text-slate-400 text-[11px]">Context:</span>
                <span className="font-medium text-slate-200">{currentUserContext.name || currentUserContext.key}</span>
              </div>
              <ChevronDown className="h-3.5 w-3.5 text-slate-500" />
            </button>

            {showUserDropdown && (
              <div className="absolute right-0 mt-2 w-72 rounded-lg border border-slate-800 bg-slate-900 p-2 shadow-2xl z-50">
                <div className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  Simulated User Profile
                </div>
                <div className="mt-1 space-y-1">
                  {SAMPLE_USER_CONTEXTS.map((u) => (
                    <button
                      key={u.key}
                      onClick={() => {
                        setCurrentUserContext(u);
                        setShowUserDropdown(false);
                      }}
                      className={`flex w-full flex-col items-start rounded-md px-2.5 py-2 text-left transition-colors ${
                        currentUserContext.key === u.key
                          ? 'bg-indigo-950/60 border border-indigo-500/40 text-white'
                          : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                      }`}
                    >
                      <div className="flex w-full items-center justify-between text-xs font-semibold">
                        <span>{u.name}</span>
                        <span className="text-[10px] text-slate-400 uppercase">{u.plan}</span>
                      </div>
                      <div className="flex items-center gap-1 text-[11px] text-slate-400">
                        <span>{u.email}</span>
                        <span>·</span>
                        <span>{u.country}</span>
                      </div>
                    </button>
                  ))}
                </div>
                <div className="mt-2 border-t border-slate-800 pt-2">
                  <button
                    onClick={() => {
                      setActiveTab('playground');
                      setShowUserDropdown(false);
                    }}
                    className="w-full text-center text-xs font-medium text-indigo-400 hover:text-indigo-300 py-1"
                  >
                    Open Custom Context Builder →
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Live App Sandbox Quick Jump */}
          <button
            onClick={() => setActiveTab('storefront')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
              activeTab === 'storefront'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'border border-indigo-500/30 bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20'
            }`}
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Interactive Demo App</span>
          </button>

          {/* More actions: Export, Import, Reset */}
          <div className="relative">
            <button
              onClick={() => setShowMoreActions(!showMoreActions)}
              className="flex h-8 w-8 items-center justify-center rounded-md border border-slate-800 bg-slate-900 text-slate-400 transition-colors hover:text-white hover:border-slate-700"
              title="Settings & Export"
            >
              <RefreshCw className="h-3.5 w-3.5" />
            </button>

            {showMoreActions && (
              <div className="absolute right-0 mt-2 w-56 rounded-lg border border-slate-800 bg-slate-900 p-2 shadow-2xl z-50">
                <button
                  onClick={handleExport}
                  className="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white"
                >
                  <Download className="h-3.5 w-3.5 text-slate-400" />
                  <span>{copiedExport ? 'Export Downloaded!' : 'Export Config (JSON)'}</span>
                </button>
                <label className="flex w-full cursor-pointer items-center gap-2 rounded-md px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white">
                  <Upload className="h-3.5 w-3.5 text-slate-400" />
                  <span>Import Config (JSON)</span>
                  <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
                </label>
                <div className="my-1 border-t border-slate-800" />
                <button
                  onClick={() => {
                    if (confirm('Reset all flags, experiments, and segments back to demo defaults?')) {
                      resetToSampleData();
                      setShowMoreActions(false);
                    }
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-xs text-rose-400 hover:bg-rose-500/10"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Reset to Demo Defaults</span>
                </button>
              </div>
            )}
          </div>

          {/* Create Button */}
          <button
            onClick={onOpenCreateFlag}
            className="flex items-center gap-1.5 rounded-md bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm transition-all hover:bg-indigo-500 active:scale-95"
          >
            <Plus className="h-4 w-4" />
            <span>Create Flag</span>
          </button>
        </div>
      </div>
    </header>
  );
};
