import React from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Flame,
  Gauge,
  Layers,
  RotateCcw,
  ShieldAlert,
  Sparkles,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { useFlags } from '../../context/FlagContext';

export const CanaryRolloutsView: React.FC = () => {
  const { environment, flags, promoteCanary, rollbackCanary } = useFlags();

  const canaryFlags = flags.filter((f) => f.environments[environment]?.canary?.enabled);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
            <Activity className="h-4 w-4" />
          </div>
          <h2 className="text-base font-bold text-white">
            Progressive Canary Releases &amp; Automated Circuit Breakers
          </h2>
        </div>
        <p className="text-xs text-slate-400">
          Staged traffic exposure (e.g. 5% → 25% → 50% → 100%) with continuous telemetry health verification.
        </p>
      </div>

      {canaryFlags.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-800 p-12 text-center text-slate-400">
          <Activity className="h-8 w-8 text-slate-600 mx-auto mb-2" />
          <h3 className="text-sm font-semibold text-slate-300">No Active Canaries in [{environment}]</h3>
          <p className="text-xs text-slate-500 mt-1">
            Configure canary stages inside any Feature Flag to enable automated phased rollouts.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {canaryFlags.map((flag) => {
            const canary = flag.environments[environment]?.canary!;
            const currentStage = canary.stages[canary.currentStageIndex];
            const isTripped = canary.circuitBreakerTripped;
            const isLastStage = canary.currentStageIndex >= canary.stages.length - 1;

            return (
              <div
                key={flag.id}
                className={`rounded-2xl border p-6 shadow-xl transition-all ${
                  isTripped
                    ? 'border-rose-500/50 bg-rose-950/20'
                    : 'border-slate-800 bg-slate-950/70'
                }`}
              >
                {/* Header */}
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 border-b border-slate-800/80 pb-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2.5">
                      <h3 className="text-base font-bold text-white">{flag.name}</h3>
                      <span className="font-mono text-xs text-slate-500">{flag.key}</span>
                      <span
                        className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                          isTripped
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                            : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        }`}
                      >
                        {isTripped ? 'CIRCUIT BREAKER TRIPPED' : 'HEALTHY PIPELINE'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400">{flag.description}</p>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => rollbackCanary(flag.id, environment)}
                      className="flex items-center gap-1.5 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3.5 py-2 text-xs font-semibold text-rose-300 hover:bg-rose-500/20 shadow-sm"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                      <span>Instant Rollback</span>
                    </button>

                    <button
                      type="button"
                      disabled={isLastStage || isTripped}
                      onClick={() => promoteCanary(flag.id, environment)}
                      className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-md hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <span>Promote to Next Stage</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                {/* Stage Progression Pipeline */}
                <div className="pt-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {canary.stages.map((st, idx) => {
                      const isCurrent = idx === canary.currentStageIndex;
                      const isPassed = idx < canary.currentStageIndex;

                      return (
                        <div
                          key={st.stage}
                          className={`relative rounded-xl border p-4 transition-all ${
                            isCurrent
                              ? 'border-indigo-500 bg-indigo-950/30 ring-1 ring-indigo-500/30'
                              : isPassed
                              ? 'border-emerald-500/30 bg-emerald-950/20'
                              : 'border-slate-800 bg-slate-900/40 opacity-70'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-white">Stage {st.stage}</span>
                            <span className="font-mono text-xs font-bold text-indigo-300">
                              {st.percentage}% Traffic
                            </span>
                          </div>

                          <div className="mt-3 flex items-center gap-1.5 text-xs">
                            {isPassed ? (
                              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                            ) : isCurrent ? (
                              <Activity className="h-4 w-4 text-indigo-400 animate-pulse" />
                            ) : (
                              <span className="h-4 w-4 rounded-full border border-slate-600" />
                            )}
                            <span className="font-medium capitalize text-slate-200">
                              {isPassed ? 'Passed Verification' : isCurrent ? 'Active Stage' : 'Pending'}
                            </span>
                          </div>

                          <div className="mt-3 border-t border-slate-800/80 pt-2 flex items-center justify-between text-[10px] font-mono text-slate-400">
                            <span>Err: {st.errorRatePercent}%</span>
                            <span>P99: {st.latencyP99Ms}ms</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Telemetry Gauge Bar */}
                <div className="mt-6 rounded-xl border border-slate-800 bg-slate-900/50 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
                  <div className="flex items-center gap-6">
                    <div>
                      <span className="text-[10px] uppercase font-semibold text-slate-400">Active Error Rate:</span>
                      <div className="mt-0.5 font-mono font-bold text-emerald-400">
                        {currentStage?.errorRatePercent}%{' '}
                        <span className="text-[10px] text-slate-400 font-normal">
                          (Limit: &lt; {canary.maxErrorRateThreshold}%)
                        </span>
                      </div>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-semibold text-slate-400">P99 Latency:</span>
                      <div className="mt-0.5 font-mono font-bold text-white">
                        {currentStage?.latencyP99Ms} ms
                      </div>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400">
                    Auto-rollback triggers automatically if error rate breaches {canary.maxErrorRateThreshold}%.
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
