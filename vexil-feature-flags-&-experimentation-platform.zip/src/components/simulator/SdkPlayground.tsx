import React, { useState } from 'react';
import {
  Check,
  ChevronRight,
  Code2,
  Copy,
  Cpu,
  Layers,
  Play,
  RotateCcw,
  Sparkles,
  User,
  Users2,
  Zap,
} from 'lucide-react';
import { useFlags } from '../../context/FlagContext';
import { SAMPLE_USER_CONTEXTS } from '../../data/initialData';
import { Environment, EvaluationResult, UserContext } from '../../types';

interface SdkPlaygroundProps {
  initialFlagKey?: string;
}

export const SdkPlayground: React.FC<SdkPlaygroundProps> = ({ initialFlagKey }) => {
  const {
    environment,
    setEnvironment,
    currentUserContext,
    setCurrentUserContext,
    evaluateFlagForUser,
    evaluateAllFlagsForUser,
    flags,
  } = useFlags();

  const [selectedFlagKey, setSelectedFlagKey] = useState<string>(
    initialFlagKey || flags[0]?.key || ''
  );

  const [contextJson, setContextJson] = useState<string>(
    JSON.stringify(currentUserContext, null, 2)
  );
  const [contextError, setContextError] = useState<string | null>(null);

  const handleApplyPreset = (preset: UserContext) => {
    setCurrentUserContext(preset);
    setContextJson(JSON.stringify(preset, null, 2));
    setContextError(null);
  };

  const handleContextJsonChange = (val: string) => {
    setContextJson(val);
    try {
      const parsed = JSON.parse(val);
      if (!parsed.key) {
        setContextError('Context must have at least a "key" string property');
        return;
      }
      setContextError(null);
      setCurrentUserContext(parsed);
    } catch (e: any) {
      setContextError(e.message);
    }
  };

  const evaluationMatrix = evaluateAllFlagsForUser(environment, currentUserContext);
  const selectedEval: EvaluationResult | null = selectedFlagKey
    ? evaluateFlagForUser(selectedFlagKey, environment, currentUserContext)
    : null;

  return (
    <div className="space-y-6">
      {/* Playground Header */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
            <Cpu className="h-4 w-4" />
          </div>
          <h2 className="text-base font-bold text-white">SDK Playground &amp; Evaluation Trace</h2>
        </div>
        <p className="text-xs text-slate-400">
          Simulate deterministic SDK evaluations, verify complex targeting rules, and inspect the step-by-step trace engine.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Column: User Context Editor */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-indigo-400" />
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
                  User Evaluation Context
                </h3>
              </div>
              <span className="font-mono text-[10px] text-slate-400">JSON Payload</span>
            </div>

            {/* Quick Presets */}
            <div>
              <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                Load Preset Profile:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {SAMPLE_USER_CONTEXTS.map((preset) => (
                  <button
                    key={preset.key}
                    type="button"
                    onClick={() => handleApplyPreset(preset)}
                    className={`rounded border px-2.5 py-1.5 text-left text-xs transition-colors ${
                      currentUserContext.key === preset.key
                        ? 'border-indigo-500 bg-indigo-950/40 text-white'
                        : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700 hover:text-white'
                    }`}
                  >
                    <div className="font-semibold truncate">{preset.name}</div>
                    <div className="text-[10px] text-slate-400 capitalize">
                      {preset.plan} · {preset.country}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* JSON Editor */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Custom Context JSON
                </label>
                {contextError && (
                  <span className="text-[11px] text-rose-400 font-mono">Invalid JSON</span>
                )}
              </div>
              <textarea
                rows={11}
                value={contextJson}
                onChange={(e) => handleContextJsonChange(e.target.value)}
                className={`w-full rounded-lg border bg-slate-900/90 p-3 font-mono text-xs text-indigo-300 focus:outline-none ${
                  contextError ? 'border-rose-500' : 'border-slate-700 focus:border-indigo-500'
                }`}
              />
              <p className="mt-1 text-[11px] text-slate-500">
                Supports standard and custom attributes: <code className="text-slate-400">country</code>,{' '}
                <code className="text-slate-400">plan</code>, <code className="text-slate-400">email</code>,{' '}
                <code className="text-slate-400">appVersion</code>, <code className="text-slate-400">role</code>.
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: Evaluation Matrix & Step-by-Step Trace */}
        <div className="lg:col-span-7 space-y-4">
          {/* Flag Matrix selector */}
          <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="h-4 w-4 text-indigo-400" />
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
                  Evaluation Matrix [{environment}]
                </h3>
              </div>
              <div className="font-mono text-xs text-slate-400">
                User: <span className="font-semibold text-white">{currentUserContext.key}</span>
              </div>
            </div>

            {/* Flags list */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {flags.map((flag) => {
                const evalRes = evaluationMatrix[flag.key];
                const isSelected = flag.key === selectedFlagKey;
                if (!evalRes) return null;

                return (
                  <div
                    key={flag.id}
                    onClick={() => setSelectedFlagKey(flag.key)}
                    className={`cursor-pointer rounded-lg border p-3 transition-all ${
                      isSelected
                        ? 'border-indigo-500 bg-indigo-950/30'
                        : 'border-slate-800 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/80'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-white">{flag.name}</span>
                        <span className="font-mono text-[11px] text-slate-500">{flag.key}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-mono text-xs font-bold ${
                            evalRes.reason === 'OFF' ? 'text-slate-500' : 'text-emerald-400'
                          }`}
                        >
                          {typeof evalRes.value === 'object'
                            ? '{...}'
                            : String(evalRes.value)}
                        </span>
                        <ChevronRight
                          className={`h-4 w-4 ${
                            isSelected ? 'text-indigo-400' : 'text-slate-600'
                          }`}
                        />
                      </div>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                      <div>
                        <span>Variation: </span>
                        <span className="font-medium text-slate-200">{evalRes.variationName}</span>
                      </div>
                      <div className="flex items-center gap-2 font-mono">
                        <span className="text-[10px] uppercase text-indigo-400 font-semibold">
                          Reason: {evalRes.reason}
                        </span>
                        {evalRes.bucketScore !== undefined && (
                          <span>· Hash: {evalRes.bucketScore}%</span>
                        )}
                        <span>· {evalRes.evaluationTimeMs}ms</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Trace Inspector for Selected Flag */}
          {selectedEval && (
            <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-5 shadow-lg space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-purple-400" />
                  <h3 className="text-xs font-bold text-white">
                    Evaluation Trace: {selectedEval.flagKey}
                  </h3>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono">
                  <span className="text-slate-400">Resolved in:</span>
                  <span className="font-bold text-emerald-400">
                    {selectedEval.evaluationTimeMs} ms
                  </span>
                </div>
              </div>

              {/* Step Sequence */}
              <div className="space-y-2.5 pt-1">
                {selectedEval.traces.map((trace, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-3 rounded-lg border border-slate-800/80 bg-slate-900/50 p-2.5"
                  >
                    <div
                      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-bold ${
                        trace.passed
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {trace.passed ? '✓' : '—'}
                    </div>

                    <div className="flex-1 text-xs">
                      <div className="font-semibold text-slate-200">{trace.step}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{trace.description}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Final Served Result Card */}
              <div className="mt-3 rounded-lg border border-indigo-500/40 bg-indigo-950/20 p-3">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400">Final Served Variation:</span>
                    <span className="font-bold text-white">{selectedEval.variationName}</span>
                  </div>
                  <div className="font-mono text-xs font-bold text-indigo-300">
                    Value: {JSON.stringify(selectedEval.value)}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
