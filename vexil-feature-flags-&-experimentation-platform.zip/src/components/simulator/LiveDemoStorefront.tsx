import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Check,
  CheckCircle2,
  Clock,
  CreditCard,
  ExternalLink,
  Layers,
  Lock,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  User,
  Zap,
} from 'lucide-react';
import { useFlags } from '../../context/FlagContext';
import { SAMPLE_USER_CONTEXTS } from '../../data/initialData';

export const LiveDemoStorefront: React.FC = () => {
  const {
    environment,
    currentUserContext,
    setCurrentUserContext,
    evaluateFlagForUser,
    recordLiveConversion,
  } = useFlags();

  // Evaluate the storefront flags live for this user
  const checkoutFlagEval = evaluateFlagForUser('checkout-v2-one-click', environment, currentUserContext);
  const aiSearchFlagEval = evaluateFlagForUser('ai-copilot-search', environment, currentUserContext);
  const bannerFlagEval = evaluateFlagForUser('dynamic-discount-banner', environment, currentUserContext);
  const darkModeFlagEval = evaluateFlagForUser('dark-mode-engine', environment, currentUserContext);
  const killSwitchEval = evaluateFlagForUser('emergency-gateway-killswitch', environment, currentUserContext);

  const checkoutMode = checkoutFlagEval?.value || 'control_3step';
  const isAiSearch = aiSearchFlagEval?.value === true;
  const bannerConfig = bannerFlagEval?.value || { visible: false };
  const isDarkMode = darkModeFlagEval?.value === true;
  const isKillSwitchActive = killSwitchEval?.value === true;

  // Checkout modal state
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState(1);
  const [orderCompleted, setOrderCompleted] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchFeedback, setSearchFeedback] = useState<string | null>(null);

  const handleStartCheckout = () => {
    setCheckoutStep(1);
    setOrderCompleted(false);
    setCheckoutModalOpen(true);
  };

  const handleFinalizeOrder = () => {
    // Record live conversion for running checkout experiments!
    recordLiveConversion('checkout_completion_rate', 'checkout-v2-one-click');
    setOrderCompleted(true);
    setTimeout(() => {
      setCheckoutModalOpen(false);
      setOrderCompleted(false);
    }, 2200);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    recordLiveConversion('search_action_rate', 'ai-copilot-search');
    setSearchFeedback(`Executed search: "${searchQuery}" (Event recorded to Experiment EXP-102!)`);
    setTimeout(() => setSearchFeedback(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Storefront Sandbox Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between rounded-xl border border-indigo-500/30 bg-indigo-950/20 p-4 gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-md">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">Live Client Application Sandbox</h2>
            <p className="text-xs text-slate-400">
              Interactive testbed consuming feature flags in real-time. Toggle flags or switch users to watch UI mutate instantly!
            </p>
          </div>
        </div>

        {/* User quick selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Evaluating as:</span>
          <select
            value={currentUserContext.key}
            onChange={(e) => {
              const found = SAMPLE_USER_CONTEXTS.find((u) => u.key === e.target.value);
              if (found) setCurrentUserContext(found);
            }}
            className="rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white focus:border-indigo-500 focus:outline-none"
          >
            {SAMPLE_USER_CONTEXTS.map((u) => (
              <option key={u.key} value={u.key}>
                {u.name} ({u.plan} · {u.country})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Simulated Application Window */}
      <div
        className={`rounded-2xl border transition-all duration-300 overflow-hidden shadow-2xl ${
          isDarkMode
            ? 'border-slate-800 bg-slate-950 text-slate-100'
            : 'border-slate-300 bg-slate-100 text-slate-900'
        }`}
      >
        {/* Browser Top Chrome */}
        <div className={`flex items-center justify-between border-b px-4 py-2.5 text-xs ${
          isDarkMode ? 'border-slate-800 bg-slate-900/80 text-slate-400' : 'border-slate-200 bg-slate-200 text-slate-600'
        }`}>
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <span className="h-3 w-3 rounded-full bg-rose-500/80" />
              <span className="h-3 w-3 rounded-full bg-amber-500/80" />
              <span className="h-3 w-3 rounded-full bg-emerald-500/80" />
            </div>
            <span className="font-mono text-[11px] ml-2 font-medium">https://storefront.nexus-cloud.io</span>
          </div>

          <div className="flex items-center gap-3 font-mono text-[11px]">
            <span>Theme: <strong>{isDarkMode ? 'Dark' : 'Light'}</strong></span>
            <span>·</span>
            <span>Checkout: <strong>{checkoutMode}</strong></span>
          </div>
        </div>

        {/* Dynamic Promotional Banner (Controlled by dynamic-discount-banner flag) */}
        {bannerConfig && bannerConfig.visible && (
          <div
            style={{ backgroundColor: bannerConfig.accentColor || '#6366f1' }}
            className="px-4 py-2.5 text-white flex items-center justify-between text-xs transition-all shadow-inner"
          >
            <div className="flex items-center gap-2">
              <span className="bg-black/30 px-2 py-0.5 rounded font-mono font-bold text-[10px] tracking-wider">
                {bannerConfig.badge || 'PROMO'}
              </span>
              <span className="font-semibold">{bannerConfig.title}</span>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="font-mono bg-white/20 px-2 py-0.5 rounded font-bold">
                USE CODE: {bannerConfig.code}
              </span>
              <span className="text-[11px] opacity-90">Ends in {bannerConfig.countdownHours || 24}h</span>
            </div>
          </div>
        )}

        {/* Emergency Kill Switch Alert Bar (if activated) */}
        {isKillSwitchActive && (
          <div className="bg-rose-600/90 text-white px-4 py-2 text-xs flex items-center justify-between font-medium">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              <span>KILL SWITCH ACTIVE: Secondary payment routes bypassed. Emergency vault routing engaged.</span>
            </div>
            <span className="font-mono text-[11px] font-bold">CIRCUIT_BREAKER_ENGAGED</span>
          </div>
        )}

        {/* Storefront Nav Header */}
        <div className={`px-6 py-4 border-b flex flex-col md:flex-row items-center justify-between gap-4 ${
          isDarkMode ? 'border-slate-800 bg-slate-900/40' : 'border-slate-200 bg-white'
        }`}>
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white font-bold">
              N
            </div>
            <span className="font-bold tracking-tight text-base">Nexus Cloud Portal</span>
          </div>

          {/* Search Bar - Mutated by 'ai-copilot-search' flag */}
          <form onSubmit={handleSearchSubmit} className="relative flex-1 max-w-md w-full">
            <Search className={`absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isAiSearch
                  ? '✨ Ask AI Copilot (e.g., "Compare enterprise clusters")...'
                  : 'Search documentation and products...'
              }
              className={`w-full rounded-lg py-2 pl-9 pr-24 text-xs transition-all ${
                isAiSearch
                  ? isDarkMode
                    ? 'border border-indigo-500/50 bg-indigo-950/20 text-white placeholder:text-indigo-300/60 focus:border-indigo-400 focus:outline-none ring-1 ring-indigo-500/20'
                    : 'border border-indigo-300 bg-indigo-50/50 text-indigo-950 placeholder:text-indigo-500/60 focus:border-indigo-500 focus:outline-none ring-1 ring-indigo-300'
                  : isDarkMode
                  ? 'border border-slate-700 bg-slate-900 text-white placeholder:text-slate-500 focus:border-slate-500 focus:outline-none'
                  : 'border border-slate-300 bg-slate-50 text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none'
              }`}
            />
            {isAiSearch && (
              <span className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded bg-indigo-500/20 px-1.5 py-0.5 font-mono text-[9px] font-bold text-indigo-400 uppercase">
                AI Vector
              </span>
            )}
          </form>

          {/* User profile capsule in storefront */}
          <div className="flex items-center gap-3 text-xs">
            <div className="text-right">
              <div className="font-semibold">{currentUserContext.name}</div>
              <div className={`text-[10px] font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Plan: <strong className="uppercase">{currentUserContext.plan}</strong>
              </div>
            </div>
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-600/30 font-bold text-indigo-400">
              {currentUserContext.name?.charAt(0) || 'U'}
            </div>
          </div>
        </div>

        {searchFeedback && (
          <div className="bg-emerald-500/10 border-b border-emerald-500/30 px-6 py-2 text-xs text-emerald-400 flex items-center justify-between">
            <span>{searchFeedback}</span>
            <span className="font-mono text-[10px]">Telemetry Synced</span>
          </div>
        )}

        {/* Storefront Hero / Pricing Product Section */}
        <div className="p-8 max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <h1 className="text-2xl font-extrabold tracking-tight">Enterprise Cloud Cluster v3</h1>
            <p className={`text-xs max-w-lg mx-auto ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              High-availability distributed database engine with automated replication and multi-cloud failover.
            </p>
          </div>

          {/* Pricing Card */}
          <div className={`rounded-xl border p-6 max-w-md mx-auto shadow-xl ${
            isDarkMode ? 'border-slate-800 bg-slate-900/60' : 'border-slate-200 bg-white'
          }`}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base">Production Dedicated Node</h3>
                <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  Billed annually · 99.999% SLA
                </p>
              </div>
              <div className="text-right">
                <span className="text-2xl font-mono font-bold">$299</span>
                <span className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}> /mo</span>
              </div>
            </div>

            <ul className={`mt-4 space-y-2 text-xs border-t pt-4 ${
              isDarkMode ? 'border-slate-800 text-slate-300' : 'border-slate-100 text-slate-700'
            }`}>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                <span>Zero-latency local cache evaluated by Vexil Engine</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                <span>Multi-region data replication across 18 zones</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                <span>Real-time A/B conversion telemetry logging</span>
              </li>
            </ul>

            {/* CTA Button triggers the Flag-controlled checkout! */}
            <div className="mt-6">
              <button
                type="button"
                onClick={handleStartCheckout}
                className="w-full flex items-center justify-center gap-2 rounded-lg bg-indigo-600 py-3 text-xs font-bold text-white shadow-lg hover:bg-indigo-500 active:scale-98 transition-all"
              >
                <ShoppingBag className="h-4 w-4" />
                <span>
                  {checkoutMode === 'express_modal'
                    ? '1-Click Express Checkout'
                    : checkoutMode === 'bottom_drawer'
                    ? 'Instant Purchase Sheet'
                    : 'Proceed to 3-Step Checkout'}
                </span>
                <ArrowRight className="h-4 w-4 ml-1" />
              </button>

              <div className={`mt-2 text-center text-[10px] font-mono ${
                isDarkMode ? 'text-slate-500' : 'text-slate-400'
              }`}>
                Flag: checkout-v2-one-click → Variation: <strong>{checkoutMode}</strong>
              </div>
            </div>
          </div>
        </div>

        {/* Real-time Telemetry footer */}
        <div className={`border-t px-6 py-3 flex items-center justify-between text-[11px] font-mono ${
          isDarkMode ? 'border-slate-800 bg-slate-900/30 text-slate-500' : 'border-slate-200 bg-slate-100 text-slate-600'
        }`}>
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Telemetry Pipeline: CONNECTED</span>
          </div>
          <div>User: {currentUserContext.key} · Env: {environment}</div>
        </div>
      </div>

      {/* CHECKOUT MODAL IMPLEMENTATIONS (Driven by the flag variation!) */}
      {checkoutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          {orderCompleted ? (
            <div className="rounded-2xl border border-emerald-500/40 bg-slate-950 p-8 text-center max-w-sm w-full space-y-3 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <CheckCircle2 className="h-8 w-8" />
              </div>
              <h3 className="text-base font-bold text-white">Order Confirmed!</h3>
              <p className="text-xs text-slate-400">
                Conversion recorded to experiment <strong className="text-indigo-400">EXP-101</strong>!
              </p>
            </div>
          ) : checkoutMode === 'express_modal' ? (
            /* VARIANT B: 1-CLICK EXPRESS MODAL */
            <div className="w-full max-w-md rounded-2xl border border-indigo-500/40 bg-slate-950 p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-600 text-white">
                    <Zap className="h-4 w-4" />
                  </div>
                  <h3 className="text-sm font-bold text-white">1-Click Express Checkout</h3>
                </div>
                <span className="rounded bg-indigo-500/20 px-2 py-0.5 font-mono text-[10px] text-indigo-400 font-bold">
                  Variant B
                </span>
              </div>

              <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-3.5 space-y-2 text-xs">
                <div className="flex justify-between font-semibold text-white">
                  <span>Enterprise Cloud Cluster</span>
                  <span className="font-mono">$299.00/mo</span>
                </div>
                <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                  <CreditCard className="h-3.5 w-3.5 text-indigo-400" />
                  <span>Stripe Saved Card: •••• 4242 (Expires 12/28)</span>
                </div>
                <div className="text-[11px] text-slate-500">
                  Billing to: {currentUserContext.name} ({currentUserContext.email})
                </div>
              </div>

              <button
                type="button"
                onClick={handleFinalizeOrder}
                className="w-full rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 py-3 text-xs font-bold text-white shadow-lg hover:from-indigo-500 hover:to-purple-500 transition-all"
              >
                Confirm 1-Click Payment ($299.00)
              </button>

              <button
                type="button"
                onClick={() => setCheckoutModalOpen(false)}
                className="w-full text-center text-xs text-slate-500 hover:text-white"
              >
                Cancel
              </button>
            </div>
          ) : checkoutMode === 'bottom_drawer' ? (
            /* VARIANT C: BOTTOM DRAWER SHEET */
            <div className="fixed bottom-0 inset-x-0 max-w-lg mx-auto rounded-t-2xl border-t border-slate-700 bg-slate-950 p-6 shadow-2xl space-y-4">
              <div className="mx-auto h-1.5 w-12 rounded-full bg-slate-700" />
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Instant Purchase Sheet</h3>
                  <p className="text-xs text-slate-400">Mobile-first checkout flow (Variant C)</p>
                </div>
                <span className="font-mono text-base font-bold text-emerald-400">$299.00</span>
              </div>

              <button
                type="button"
                onClick={handleFinalizeOrder}
                className="w-full rounded-xl bg-emerald-600 py-3.5 text-xs font-bold text-white shadow-lg hover:bg-emerald-500"
              >
                Slide / Tap to Finalize Order
              </button>

              <button
                type="button"
                onClick={() => setCheckoutModalOpen(false)}
                className="w-full text-center text-xs text-slate-500 hover:text-white"
              >
                Dismiss
              </button>
            </div>
          ) : (
            /* CONTROL: TRADITIONAL 3-STEP CHECKOUT */
            <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-950 p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-sm font-bold text-white">Standard Checkout (Control)</h3>
                <span className="font-mono text-[11px] text-slate-400">Step {checkoutStep} of 3</span>
              </div>

              {checkoutStep === 1 && (
                <div className="space-y-3 text-xs">
                  <div className="font-semibold text-slate-200">Step 1: Shipping &amp; Billing Address</div>
                  <input
                    type="text"
                    defaultValue="100 Market St, Suite 400"
                    className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-white"
                  />
                  <input
                    type="text"
                    defaultValue="San Francisco, CA 94105"
                    className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-white"
                  />
                  <button
                    type="button"
                    onClick={() => setCheckoutStep(2)}
                    className="w-full rounded-lg bg-indigo-600 py-2.5 font-bold text-white hover:bg-indigo-500"
                  >
                    Continue to Payment Options →
                  </button>
                </div>
              )}

              {checkoutStep === 2 && (
                <div className="space-y-3 text-xs">
                  <div className="font-semibold text-slate-200">Step 2: Enter Credit Card</div>
                  <input
                    type="text"
                    defaultValue="4242 •••• •••• 4242"
                    className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-white font-mono"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      defaultValue="12/28"
                      className="rounded border border-slate-700 bg-slate-900 px-3 py-2 text-white font-mono"
                    />
                    <input
                      type="text"
                      defaultValue="882"
                      className="rounded border border-slate-700 bg-slate-900 px-3 py-2 text-white font-mono"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => setCheckoutStep(3)}
                    className="w-full rounded-lg bg-indigo-600 py-2.5 font-bold text-white hover:bg-indigo-500"
                  >
                    Review Order →
                  </button>
                </div>
              )}

              {checkoutStep === 3 && (
                <div className="space-y-3 text-xs">
                  <div className="font-semibold text-slate-200">Step 3: Review &amp; Submit</div>
                  <div className="rounded border border-slate-800 bg-slate-900 p-3 space-y-1 text-slate-300">
                    <div className="flex justify-between font-bold">
                      <span>Total:</span>
                      <span className="font-mono">$299.00</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleFinalizeOrder}
                    className="w-full rounded-lg bg-emerald-600 py-2.5 font-bold text-white hover:bg-emerald-500"
                  >
                    Complete Purchase
                  </button>
                </div>
              )}

              <button
                type="button"
                onClick={() => setCheckoutModalOpen(false)}
                className="w-full text-center text-xs text-slate-500 hover:text-white"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
