import React, { useState } from 'react';
import { AlertTriangle, ShieldAlert, X } from 'lucide-react';
import { Environment, FeatureFlag } from '../../types';

interface ConfirmKillSwitchModalProps {
  flag: FeatureFlag;
  environment: Environment;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmKillSwitchModal: React.FC<ConfirmKillSwitchModalProps> = ({
  flag,
  environment,
  onConfirm,
  onCancel,
}) => {
  const currentState = flag.environments[environment]?.enabled ?? false;
  const targetState = !currentState;
  const isKillSwitch = flag.category === 'killswitch';
  const isProd = environment === 'production';

  const [confirmInput, setConfirmInput] = useState('');
  const requiresTypedConfirmation = isKillSwitch || (isProd && !targetState); // turning off in prod requires typing confirm

  const isConfirmed = !requiresTypedConfirmation || confirmInput.toLowerCase() === flag.key.toLowerCase();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md">
      <div className="w-full max-w-lg rounded-xl border border-rose-500/40 bg-slate-950 p-6 shadow-2xl">
        <div className="flex items-start gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-400">
            {isKillSwitch ? <ShieldAlert className="h-6 w-6" /> : <AlertTriangle className="h-6 w-6" />}
          </div>

          <div className="flex-1 space-y-1">
            <h3 className="text-base font-bold text-white">
              {isKillSwitch
                ? `Activate Emergency Kill Switch?`
                : `Confirm State Change in [${environment.toUpperCase()}]`}
            </h3>
            <p className="text-xs text-slate-400">
              You are about to change the active state of{' '}
              <span className="font-semibold text-white">{flag.name}</span> in the{' '}
              <span className="font-mono text-rose-400 font-bold uppercase">{environment}</span>{' '}
              environment.
            </p>
          </div>

          <button onClick={onCancel} className="text-slate-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* State Transition Visual */}
        <div className="mt-5 rounded-lg border border-slate-800 bg-slate-900/70 p-4">
          <div className="flex items-center justify-between text-xs">
            <div className="flex flex-col">
              <span className="text-[10px] uppercase font-semibold text-slate-500">Current State</span>
              <span className={`font-mono text-sm font-bold ${currentState ? 'text-emerald-400' : 'text-slate-400'}`}>
                {currentState ? 'ENABLED (ON)' : 'DISABLED (OFF)'}
              </span>
            </div>

            <div className="text-slate-500 font-mono text-sm">→</div>

            <div className="flex flex-col text-right">
              <span className="text-[10px] uppercase font-semibold text-slate-500">New State</span>
              <span className={`font-mono text-sm font-bold ${targetState ? 'text-emerald-400' : 'text-rose-400'}`}>
                {targetState ? 'ENABLED (ON)' : 'DISABLED (OFF)'}
              </span>
            </div>
          </div>

          <div className="mt-3 border-t border-slate-800 pt-2.5 text-[11px] text-slate-400">
            {targetState
              ? `Users in ${environment} will immediately be evaluated against targeted rules and progressive rollouts.`
              : `All users in ${environment} will instantly fall back to the default OFF variation ("${
                  flag.variations.find((v) => v.id === flag.environments[environment]?.offVariationId)?.name ||
                  flag.variations[0]?.name
                }").`}
          </div>
        </div>

        {requiresTypedConfirmation && (
          <div className="mt-4 space-y-2">
            <label className="block text-xs text-slate-300">
              To confirm, type <span className="font-mono font-bold text-white select-all">{flag.key}</span> below:
            </label>
            <input
              type="text"
              value={confirmInput}
              onChange={(e) => setConfirmInput(e.target.value)}
              placeholder={flag.key}
              className="w-full rounded border border-rose-500/40 bg-slate-900 px-3 py-2 font-mono text-xs text-white focus:border-rose-500 focus:outline-none"
            />
          </div>
        )}

        <div className="mt-6 flex items-center justify-end gap-3 border-t border-slate-800/80 pt-4">
          <button
            type="button"
            onClick={onCancel}
            className="rounded-lg border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!isConfirmed}
            onClick={onConfirm}
            className={`flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white shadow-lg transition-all ${
              targetState
                ? 'bg-emerald-600 hover:bg-emerald-500'
                : 'bg-rose-600 hover:bg-rose-500'
            } disabled:opacity-40 disabled:cursor-not-allowed`}
          >
            <span>Confirm &amp; Apply Immediately</span>
          </button>
        </div>
      </div>
    </div>
  );
};
