import React, { useState } from 'react';
import {
  Award,
  CheckCircle2,
  ChevronRight,
  Clock,
  FlaskConical,
  Gauge,
  Pause,
  Play,
  Plus,
  Search,
  Sparkles,
} from 'lucide-react';
import { useFlags } from '../../context/FlagContext';
import { Experiment } from '../../types';
import { CreateExperimentModal } from './CreateExperimentModal';
import { ExperimentDetail } from './ExperimentDetail';

export const ExperimentsList: React.FC = () => {
  const { experiments, flags, environment } = useFlags();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'running' | 'concluded' | 'draft'>('all');
  const [selectedExpId, setSelectedExpId] = useState<string | null>(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);

  if (selectedExpId) {
    return (
      <ExperimentDetail
        experimentId={selectedExpId}
        onBack={() => setSelectedExpId(null)}
      />
    );
  }

  const filteredExperiments = experiments.filter((exp) => {
    const matchesSearch =
      exp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      exp.key.toLowerCase().includes(searchQuery.toLowerCase()) ||
      exp.description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' || exp.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Top Filter and Create Bar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search experiments by name or key..."
            className="w-full rounded-lg border border-slate-800 bg-slate-900/80 py-2 pl-9 pr-4 text-xs text-white placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900/60 p-1">
            {(['all', 'running', 'concluded', 'draft'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`rounded px-3 py-1 text-xs font-semibold capitalize transition-colors ${
                  statusFilter === st
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCreateModalOpen(true)}
            className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500"
          >
            <Plus className="h-4 w-4" />
            <span>New Experiment</span>
          </button>
        </div>
      </div>

      {/* Experiments Grid / List */}
      <div className="grid grid-cols-1 gap-4">
        {filteredExperiments.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-800 p-12 text-center">
            <FlaskConical className="h-8 w-8 text-slate-600 mx-auto mb-2" />
            <h3 className="text-sm font-semibold text-slate-300">No experiments found</h3>
            <p className="text-xs text-slate-500 mt-1">
              Create an A/B test linked to a feature flag to measure conversion and engagement.
            </p>
            <button
              onClick={() => setCreateModalOpen(true)}
              className="mt-4 rounded-md bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500"
            >
              Design Experiment
            </button>
          </div>
        ) : (
          filteredExperiments.map((exp) => {
            const flag = flags.find((f) => f.id === exp.flagId);
            const totalVisitors = Object.values(exp.stats).reduce((acc, s) => acc + s.sampleSize, 0);
            const sampleProgress = Math.min(100, Math.round((totalVisitors / exp.targetSampleSize) * 100));
            const winningStat = Object.values(exp.stats).find((s) => s.isWinner);

            return (
              <div
                key={exp.id}
                onClick={() => setSelectedExpId(exp.id)}
                className="group cursor-pointer rounded-xl border border-slate-800 bg-slate-950/70 p-5 shadow-lg transition-all hover:border-slate-700 hover:bg-slate-900/50"
              >
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  {/* Left info */}
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2.5">
                      <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                        {exp.name}
                      </h3>
                      <span className="font-mono text-[11px] text-slate-500">{exp.key}</span>
                      <span
                        className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                          exp.status === 'running'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : exp.status === 'concluded'
                            ? 'bg-purple-500/10 text-purple-400 border border-purple-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {exp.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-400 line-clamp-1">{exp.description}</p>

                    <div className="flex items-center gap-2 text-[11px] text-slate-500 font-sans">
                      <span>Flag: <strong className="text-slate-300">{flag?.name || exp.flagId}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>Metric: <strong className="text-slate-300">{exp.primaryMetric.name}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>Env: <strong className="text-slate-300 uppercase">{exp.environment}</strong></span>
                    </div>
                  </div>

                  {/* Right stats & progress */}
                  <div className="flex items-center gap-6 lg:border-l lg:border-slate-800/80 lg:pl-6 shrink-0">
                    {/* Sample Power Bar */}
                    <div className="w-36 space-y-1">
                      <div className="flex justify-between text-[11px] font-mono">
                        <span className="text-slate-400">Sample</span>
                        <span className="text-white font-bold">{totalVisitors.toLocaleString()}</span>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-indigo-500 rounded-full"
                          style={{ width: `${sampleProgress}%` }}
                        />
                      </div>
                      <div className="text-[10px] text-slate-500 text-right">{sampleProgress}% collected</div>
                    </div>

                    {/* Significance / Verdict Box */}
                    <div className="w-48 text-right">
                      {winningStat ? (
                        <div className="space-y-0.5">
                          <div className="flex items-center justify-end gap-1 text-emerald-400 font-bold text-xs">
                            <Award className="h-3.5 w-3.5" />
                            <span>Winner: +{winningStat.liftPercent}%</span>
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            {winningStat.variationName} (p={winningStat.pValue})
                          </div>
                        </div>
                      ) : exp.status === 'running' ? (
                        <div className="space-y-0.5">
                          <div className="text-xs text-indigo-300 font-semibold">Running Test</div>
                          <div className="text-[10px] text-slate-500 font-mono">Gathering traffic</div>
                        </div>
                      ) : (
                        <div className="space-y-0.5">
                          <div className="text-xs text-slate-400 font-medium">Draft Experiment</div>
                          <div className="text-[10px] text-slate-500">Ready to launch</div>
                        </div>
                      )}
                    </div>

                    <ChevronRight className="h-5 w-5 text-slate-600 group-hover:text-indigo-400 transition-colors" />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {createModalOpen && <CreateExperimentModal onClose={() => setCreateModalOpen(false)} />}
    </div>
  );
};
