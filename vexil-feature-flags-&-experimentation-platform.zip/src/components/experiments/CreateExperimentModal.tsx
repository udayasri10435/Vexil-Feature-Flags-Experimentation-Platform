import React, { useState } from 'react';
import { Award, FlaskConical, Plus, X } from 'lucide-react';
import { useFlags } from '../../context/FlagContext';
import { Environment, Experiment, Metric } from '../../types';

interface CreateExperimentModalProps {
  onClose: () => void;
}

export const CreateExperimentModal: React.FC<CreateExperimentModalProps> = ({ onClose }) => {
  const { flags, createExperiment, environment } = useFlags();

  const [name, setName] = useState('');
  const [key, setKey] = useState('');
  const [description, setDescription] = useState('');
  const [hypothesis, setHypothesis] = useState('');
  const [selectedFlagId, setSelectedFlagId] = useState(flags[0]?.id || '');
  const [metricName, setMetricName] = useState('Checkout Conversion Rate');
  const [metricKey, setMetricKey] = useState('checkout_cr');
  const [targetSample, setTargetSample] = useState(10000);
  const [selectedEnv, setSelectedEnv] = useState<Environment>(environment);

  const selectedFlag = flags.find((f) => f.id === selectedFlagId) || flags[0];

  const handleNameChange = (val: string) => {
    setName(val);
    const slug = `EXP-${val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')}`;
    setKey(slug);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !key || !selectedFlag) return;

    const variations = selectedFlag.variations.map((v, i) => ({
      variationId: v.id,
      trafficAllocation: Number((100 / selectedFlag.variations.length).toFixed(1)),
    }));

    const primaryMetric: Metric = {
      id: `metric-${Date.now()}`,
      key: metricKey,
      name: metricName,
      type: 'conversion_rate',
      goal: 'increase',
    };

    const initialStats: Record<string, any> = {};
    selectedFlag.variations.forEach((v) => {
      initialStats[v.id] = {
        variationId: v.id,
        variationName: v.name,
        trafficAllocation: Number((100 / selectedFlag.variations.length).toFixed(1)),
        sampleSize: 0,
        conversions: 0,
        conversionRate: 0,
        standardError: 0,
        zScore: 0,
        pValue: 1.0,
        confidenceInterval: [0, 0],
        liftPercent: 0,
        isSignificant: false,
        isWinner: false,
      };
    });

    const newExp: Experiment = {
      id: `exp-${Date.now()}`,
      key: key.trim(),
      name: name.trim(),
      description: description.trim(),
      flagId: selectedFlag.id,
      environment: selectedEnv,
      status: 'draft',
      hypothesis: hypothesis.trim(),
      baselineVariationId: selectedFlag.variations[0]?.id || '',
      variations,
      primaryMetric,
      targetSampleSize: targetSample,
      confidenceLevel: 95,
      stats: initialStats,
    };

    createExperiment(newExp);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="flex w-full max-w-xl flex-col rounded-xl border border-slate-800 bg-slate-950 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-600 text-white">
              <FlaskConical className="h-4 w-4" />
            </div>
            <h2 className="text-base font-bold text-white">Design New A/B Experiment</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleCreate} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Experiment Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="e.g. Hero CTA Copy Optimization"
              className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Experiment Key</label>
              <input
                type="text"
                required
                value={key}
                onChange={(e) => setKey(e.target.value)}
                placeholder="EXP-hero-cta"
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 font-mono text-xs text-indigo-400 focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Environment</label>
              <select
                value={selectedEnv}
                onChange={(e) => setSelectedEnv(e.target.value as Environment)}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none capitalize"
              >
                <option value="production">production</option>
                <option value="staging">staging</option>
                <option value="development">development</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Associated Feature Flag</label>
            <select
              value={selectedFlagId}
              onChange={(e) => setSelectedFlagId(e.target.value)}
              className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
            >
              {flags.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.key}) - {f.variations.length} variations
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Scientific Hypothesis</label>
            <textarea
              rows={2}
              required
              value={hypothesis}
              onChange={(e) => setHypothesis(e.target.value)}
              placeholder="If we [change], then [metric will increase by X%] because [reason]..."
              className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Primary Metric Name</label>
              <input
                type="text"
                required
                value={metricName}
                onChange={(e) => {
                  setMetricName(e.target.value);
                  setMetricKey(e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '_'));
                }}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Target Sample Size</label>
              <input
                type="number"
                min="100"
                step="500"
                value={targetSample}
                onChange={(e) => setTargetSample(parseInt(e.target.value) || 5000)}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 font-mono text-xs text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-800 pt-4 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-5 py-2 text-xs font-semibold text-white shadow-md hover:bg-indigo-500"
            >
              <Plus className="h-4 w-4" />
              <span>Create Experiment</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
