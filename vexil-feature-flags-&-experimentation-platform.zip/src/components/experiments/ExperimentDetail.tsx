import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  Award,
  CheckCircle2,
  ChevronRight,
  Clock,
  Compass,
  Download,
  ExternalLink,
  FlaskConical,
  Gauge,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  TrendingUp,
  Users,
} from 'lucide-react';
import { useFlags } from '../../context/FlagContext';
import { Experiment } from '../../types';

interface ExperimentDetailProps {
  experimentId: string;
  onBack: () => void;
  onOpenFlagDetail?: (flagId: string) => void;
}

export const ExperimentDetail: React.FC<ExperimentDetailProps> = ({
  experimentId,
  onBack,
  onOpenFlagDetail,
}) => {
  const {
    experiments,
    flags,
    startExperiment,
    pauseExperiment,
    concludeExperiment,
    simulateTraffic,
  } = useFlags();

  const [isSimulating, setIsSimulating] = useState(false);
  const [concludeModalOpen, setConcludeModalOpen] = useState(false);
  const [selectedWinnerId, setSelectedWinnerId] = useState<string>('');

  const exp = experiments.find((e) => e.id === experimentId);
  if (!exp) {
    return (
      <div className="p-8 text-center text-slate-400">
        <p>Experiment not found.</p>
        <button onClick={onBack} className="mt-2 text-indigo-400 hover:underline">
          Return to experiments list
        </button>
      </div>
    );
  }

  const linkedFlag = flags.find((f) => f.id === exp.flagId);

  // Identify winning variation
  const winningVariationStat = Object.values(exp.stats).find((s) => s.isWinner);
  const totalVisitors = Object.values(exp.stats).reduce((acc, s) => acc + s.sampleSize, 0);
  const totalConversions = Object.values(exp.stats).reduce((acc, s) => acc + s.conversions, 0);
  const sampleProgress = Math.min(100, Math.round((totalVisitors / exp.targetSampleSize) * 100));

  const handleSimulate = (count: number) => {
    setIsSimulating(true);
    simulateTraffic(exp.id, count);
    setTimeout(() => setIsSimulating(false), 300);
  };

  const handleConfirmConclude = (promoteToProd: boolean) => {
    concludeExperiment(exp.id, selectedWinnerId || winningVariationStat?.variationId || exp.baselineVariationId, promoteToProd);
    setConcludeModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Breadcrumb & Actions Bar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>All Experiments</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-slate-500">{exp.key}</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="font-mono text-xs text-indigo-400 uppercase">[{exp.environment}]</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {exp.status === 'draft' && (
            <button
              onClick={() => startExperiment(exp.id)}
              className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500 shadow-sm"
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              <span>Launch Experiment</span>
            </button>
          )}

          {exp.status === 'running' && (
            <>
              <button
                onClick={() => pauseExperiment(exp.id)}
                className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700"
              >
                <Pause className="h-3.5 w-3.5" />
                <span>Pause</span>
              </button>
              <button
                onClick={() => {
                  setSelectedWinnerId(winningVariationStat?.variationId || exp.variations[1]?.variationId || '');
                  setConcludeModalOpen(true);
                }}
                className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500 shadow-md"
              >
                <Award className="h-3.5 w-3.5" />
                <span>Conclude &amp; Roll Out</span>
              </button>
            </>
          )}

          {exp.status === 'concluded' && (
            <div className="flex items-center gap-2 text-xs font-medium text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 rounded-lg px-3 py-1.5">
              <CheckCircle2 className="h-4 w-4" />
              <span>Experiment Concluded</span>
            </div>
          )}
        </div>
      </div>

      {/* Main Title & Hypothesis Card */}
      <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-6 shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
          <div className="space-y-2 flex-1">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-purple-600/20 text-purple-400 border border-purple-500/30">
                <FlaskConical className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">{exp.name}</h1>
                <p className="text-xs text-slate-400">{exp.description}</p>
              </div>
            </div>

            <div className="mt-3 rounded-lg border border-slate-800/80 bg-slate-900/50 p-3.5 text-xs">
              <span className="font-semibold text-indigo-300">HYPOTHESIS: </span>
              <span className="text-slate-300 italic">{exp.hypothesis}</span>
            </div>
          </div>

          {/* Quick Metrics Badge */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 shrink-0">
            <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-3 text-center">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Primary Metric</span>
              <div className="mt-1 font-semibold text-xs text-white truncate max-w-[130px]">{exp.primaryMetric.name}</div>
              <div className="text-[10px] text-emerald-400 font-mono">Goal: {exp.primaryMetric.goal}</div>
            </div>

            <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-3 text-center">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Total Sample</span>
              <div className="mt-1 font-mono text-base font-bold text-white">{totalVisitors.toLocaleString()}</div>
              <div className="text-[10px] text-slate-400 font-mono">{sampleProgress}% of {exp.targetSampleSize.toLocaleString()}</div>
            </div>

            <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-3 text-center col-span-2 sm:col-span-1">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Confidence</span>
              <div className="mt-1 font-mono text-base font-bold text-indigo-400">{exp.confidenceLevel}%</div>
              <div className="text-[10px] text-slate-400 font-mono">Two-tailed Z-test</div>
            </div>
          </div>
        </div>
      </div>

      {/* Statistical Outcome Banner */}
      {winningVariationStat ? (
        <div className="rounded-xl border border-emerald-500/40 bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-950 p-5 shadow-lg">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                <Award className="h-6 w-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white text-sm">
                    Statistically Significant Winner Detected!
                  </span>
                  <span className="font-mono text-xs font-semibold text-emerald-400">
                    p = {winningVariationStat.pValue} (&lt; 0.05)
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">
                  <span className="font-semibold text-white">{winningVariationStat.variationName}</span> delivers a{' '}
                  <span className="font-mono font-bold text-emerald-400">+{winningVariationStat.liftPercent}%</span> conversion lift with 95% confidence interval [{winningVariationStat.confidenceInterval[0]}%, {winningVariationStat.confidenceInterval[1]}%].
                </p>
              </div>
            </div>

            {exp.status === 'running' && (
              <button
                onClick={() => {
                  setSelectedWinnerId(winningVariationStat.variationId);
                  setConcludeModalOpen(true);
                }}
                className="shrink-0 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-emerald-500 transition-all"
              >
                Promote Winner to 100% Production
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <Gauge className="h-4 w-4 text-indigo-400" />
              <span>
                Gathering statistical power: {totalVisitors.toLocaleString()} / {exp.targetSampleSize.toLocaleString()} visitors collected ({sampleProgress}%).
              </span>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">
              Minimum Detectable Effect (MDE): 5.0%
            </span>
          </div>
          <div className="mt-2.5 h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-indigo-500 rounded-full transition-all duration-500"
              style={{ width: `${sampleProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* Traffic Simulator Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between rounded-xl border border-slate-800 bg-slate-900/70 p-4 gap-3">
        <div className="flex items-center gap-2.5">
          <Sparkles className="h-4 w-4 text-indigo-400" />
          <div>
            <h4 className="text-xs font-semibold text-white">Live Synthetic Traffic Generator</h4>
            <p className="text-[11px] text-slate-400">
              Inject simulated visitor sessions to test statistical convergence, z-scores, and p-values live.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={isSimulating}
            onClick={() => handleSimulate(500)}
            className="rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 font-mono text-xs font-medium text-slate-200 hover:bg-slate-700 hover:text-white disabled:opacity-50"
          >
            +500 Visitors
          </button>
          <button
            type="button"
            disabled={isSimulating}
            onClick={() => handleSimulate(2500)}
            className="rounded-lg bg-indigo-600 px-3 py-1.5 font-mono text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50"
          >
            +2,500 Visitors
          </button>
        </div>
      </div>

      {/* Variations Statistical Comparison Table */}
      <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/70 shadow-lg">
        <div className="border-b border-slate-800 bg-slate-900/50 px-6 py-3.5">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
            Variation Performance &amp; Statistical Bounds
          </h3>
        </div>

        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-800/80 bg-slate-900/20 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              <th className="py-3 px-6">Variation</th>
              <th className="py-3 px-4 text-right">Traffic Share</th>
              <th className="py-3 px-4 text-right">Visitors</th>
              <th className="py-3 px-4 text-right">Conversions</th>
              <th className="py-3 px-4 text-right">Conv. Rate</th>
              <th className="py-3 px-4 text-right">Relative Lift</th>
              <th className="py-3 px-4 text-center">95% Confidence Interval</th>
              <th className="py-3 px-4 text-right">p-Value</th>
              <th className="py-3 px-6 text-right">Significance</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {exp.variations.map((v) => {
              const stat = exp.stats[v.variationId];
              if (!stat) return null;
              const isBaseline = v.variationId === exp.baselineVariationId;

              return (
                <tr
                  key={v.variationId}
                  className={`transition-colors ${
                    stat.isWinner
                      ? 'bg-emerald-950/20 text-emerald-300 font-medium'
                      : 'hover:bg-slate-900/40 text-slate-300'
                  }`}
                >
                  {/* Name */}
                  <td className="py-3.5 px-6 font-sans">
                    <div className="flex items-center gap-2">
                      {stat.isWinner && <Award className="h-4 w-4 text-emerald-400 shrink-0" />}
                      <div>
                        <span className="font-semibold text-white">{stat.variationName}</span>
                        {isBaseline && (
                          <span className="ml-2 font-mono text-[10px] text-slate-400 uppercase">
                            (Baseline Control)
                          </span>
                        )}
                      </div>
                    </div>
                  </td>

                  {/* Traffic Allocation */}
                  <td className="py-3.5 px-4 text-right text-slate-400">
                    {v.trafficAllocation}%
                  </td>

                  {/* Sample Size */}
                  <td className="py-3.5 px-4 text-right text-white">
                    {stat.sampleSize.toLocaleString()}
                  </td>

                  {/* Conversions */}
                  <td className="py-3.5 px-4 text-right text-white">
                    {stat.conversions.toLocaleString()}
                  </td>

                  {/* Conversion Rate */}
                  <td className="py-3.5 px-4 text-right font-bold text-white">
                    {stat.conversionRate}%
                  </td>

                  {/* Relative Lift */}
                  <td className="py-3.5 px-4 text-right">
                    {isBaseline ? (
                      <span className="text-slate-500">—</span>
                    ) : (
                      <span
                        className={`font-bold ${
                          stat.liftPercent > 0
                            ? 'text-emerald-400'
                            : stat.liftPercent < 0
                            ? 'text-rose-400'
                            : 'text-slate-400'
                        }`}
                      >
                        {stat.liftPercent > 0 ? `+${stat.liftPercent}%` : `${stat.liftPercent}%`}
                      </span>
                    )}
                  </td>

                  {/* Confidence Interval Error Bounds */}
                  <td className="py-3.5 px-4 text-center">
                    {isBaseline ? (
                      <span className="text-slate-500">—</span>
                    ) : (
                      <div className="flex items-center justify-center gap-1.5 text-[11px]">
                        <span className="text-slate-400">[{stat.confidenceInterval[0]}%,</span>
                        <span className="text-slate-400">{stat.confidenceInterval[1]}%]</span>
                      </div>
                    )}
                  </td>

                  {/* p-value */}
                  <td className="py-3.5 px-4 text-right">
                    {isBaseline ? (
                      <span className="text-slate-500">—</span>
                    ) : (
                      <span
                        className={`font-semibold ${
                          stat.pValue < 0.05 ? 'text-emerald-400' : 'text-slate-400'
                        }`}
                      >
                        {stat.pValue}
                      </span>
                    )}
                  </td>

                  {/* Statistical Verdict */}
                  <td className="py-3.5 px-6 text-right font-sans">
                    {isBaseline ? (
                      <span className="text-slate-400 text-xs">Control</span>
                    ) : stat.isWinner ? (
                      <span className="text-emerald-400 font-bold text-xs">Significant Winner</span>
                    ) : stat.isSignificant && stat.liftPercent < 0 ? (
                      <span className="text-rose-400 font-bold text-xs">Underperforming</span>
                    ) : (
                      <span className="text-slate-500 text-xs">Inconclusive</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Conclude Modal */}
      {concludeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-xl border border-slate-800 bg-slate-950 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                <Award className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Conclude Experiment</h3>
                <p className="text-xs text-slate-400">{exp.name}</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Select Winning Variation to Promote
              </label>
              <select
                value={selectedWinnerId}
                onChange={(e) => setSelectedWinnerId(e.target.value)}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-indigo-500 focus:outline-none"
              >
                {exp.variations.map((v) => (
                  <option key={v.variationId} value={v.variationId}>
                    {exp.stats[v.variationId]?.variationName || v.variationId} ({exp.stats[v.variationId]?.conversionRate}%)
                  </option>
                ))}
              </select>
            </div>

            <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-3 text-xs text-slate-300">
              Promoting will automatically update the underlying feature flag's production fallthrough strategy to deliver 100% of traffic to the chosen variation.
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setConcludeModalOpen(false)}
                className="rounded-lg border border-slate-700 bg-slate-800 px-4 py-2 text-xs text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleConfirmConclude(true)}
                className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 shadow-md"
              >
                Conclude &amp; Roll Out to 100%
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
