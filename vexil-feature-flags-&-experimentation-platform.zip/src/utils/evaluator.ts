import {
  Environment,
  EvaluationResult,
  EvaluationStepTrace,
  FeatureFlag,
  RuleOperator,
  Segment,
  UserContext,
  Variation,
} from '../types';
import { getBucketScore } from './hashing';

function getContextValue(context: UserContext, attribute: string): any {
  if (attribute === 'key') return context.key;
  if (attribute === 'name') return context.name;
  if (attribute === 'email') return context.email;
  if (attribute === 'country') return context.country;
  if (attribute === 'plan') return context.plan;
  if (attribute === 'appVersion') return context.appVersion;
  if (attribute === 'role') return context.role;
  if (attribute === 'isInternal') return context.isInternal;
  if (context.customAttributes && attribute in context.customAttributes) {
    return context.customAttributes[attribute];
  }
  return undefined;
}

export function evaluateOperator(
  contextValue: any,
  operator: RuleOperator,
  values: string[],
  segments: Segment[] = []
): boolean {
  if (operator === 'in_segment') {
    const targetSegmentKey = values[0];
    const segment = segments.find((s) => s.key === targetSegmentKey || s.id === targetSegmentKey);
    if (!segment) return false;
    // Check included / excluded users
    if (contextValue?.key) {
      if (segment.excludedUserKeys.includes(contextValue.key)) return false;
      if (segment.includedUserKeys.includes(contextValue.key)) return true;
    }
    // Check segment sub-rules
    if (segment.rules.length > 0) {
      return segment.rules.every((rule) => {
        const val = getContextValue(contextValue, rule.attribute);
        return evaluateOperator(val, rule.operator, rule.values);
      });
    }
    return false;
  }

  if (contextValue === undefined || contextValue === null) {
    return operator === 'not_equals' || operator === 'not_in_list';
  }

  const strVal = String(contextValue).toLowerCase();

  switch (operator) {
    case 'equals':
      return values.some((v) => strVal === v.toLowerCase());
    case 'not_equals':
      return !values.some((v) => strVal === v.toLowerCase());
    case 'contains':
      return values.some((v) => strVal.includes(v.toLowerCase()));
    case 'not_contains':
      return !values.some((v) => strVal.includes(v.toLowerCase()));
    case 'starts_with':
      return values.some((v) => strVal.startsWith(v.toLowerCase()));
    case 'ends_with':
      return values.some((v) => strVal.endsWith(v.toLowerCase()));
    case 'in_list':
      return values.some((v) => v.toLowerCase() === strVal);
    case 'not_in_list':
      return !values.some((v) => v.toLowerCase() === strVal);
    case 'greater_than': {
      const numCtx = parseFloat(strVal);
      const numTarget = parseFloat(values[0]);
      if (isNaN(numCtx) || isNaN(numTarget)) return false;
      return numCtx > numTarget;
    }
    case 'less_than': {
      const numCtx = parseFloat(strVal);
      const numTarget = parseFloat(values[0]);
      if (isNaN(numCtx) || isNaN(numTarget)) return false;
      return numCtx < numTarget;
    }
    case 'matches_regex':
      try {
        const regex = new RegExp(values[0], 'i');
        return regex.test(strVal);
      } catch {
        return false;
      }
    default:
      return false;
  }
}

function resolveRolloutVariation(
  bucketScore: number,
  rolloutDistribution: { variationId: string; percentage: number }[],
  variations: Variation[],
  fallbackVariationId: string
): Variation {
  let cumulative = 0;
  for (const item of rolloutDistribution) {
    cumulative += item.percentage;
    if (bucketScore < cumulative) {
      const found = variations.find((v) => v.id === item.variationId);
      if (found) return found;
    }
  }
  return (
    variations.find((v) => v.id === fallbackVariationId) ||
    variations[0]
  );
}

export function evaluateFlag(
  flag: FeatureFlag,
  environment: Environment,
  context: UserContext,
  segments: Segment[] = []
): EvaluationResult {
  const startTime = performance.now();
  const traces: EvaluationStepTrace[] = [];
  const envConfig = flag.environments[environment];

  if (!envConfig) {
    const defaultVar = flag.variations[0];
    return {
      flagKey: flag.key,
      flagId: flag.id,
      environment,
      userKey: context.key,
      value: defaultVar.value,
      variationKey: defaultVar.key,
      variationId: defaultVar.id,
      variationName: defaultVar.name,
      reason: 'DEFAULT_VARIATION',
      evaluationTimeMs: 0.1,
      traces: [{ step: 'Env Check', description: `Environment ${environment} not found`, passed: false }],
    };
  }

  // 1. Check if archived or disabled in environment
  if (flag.archived) {
    traces.push({
      step: 'Archived Flag',
      description: 'Flag is archived. Serving default off variation.',
      passed: true,
    });
    const offVar = flag.variations.find((v) => v.id === envConfig.offVariationId) || flag.variations[0];
    return {
      flagKey: flag.key,
      flagId: flag.id,
      environment,
      userKey: context.key,
      value: offVar.value,
      variationKey: offVar.key,
      variationId: offVar.id,
      variationName: offVar.name,
      reason: 'OFF',
      evaluationTimeMs: Number((performance.now() - startTime).toFixed(2)),
      traces,
    };
  }

  if (!envConfig.enabled) {
    traces.push({
      step: 'Flag Enabled Check',
      description: `Flag is OFF in ${environment}. Serving OFF variation.`,
      passed: false,
    });
    const offVar = flag.variations.find((v) => v.id === envConfig.offVariationId) || flag.variations[0];
    return {
      flagKey: flag.key,
      flagId: flag.id,
      environment,
      userKey: context.key,
      value: offVar.value,
      variationKey: offVar.key,
      variationId: offVar.id,
      variationName: offVar.name,
      reason: 'OFF',
      evaluationTimeMs: Number((performance.now() - startTime).toFixed(2)),
      traces,
    };
  }

  traces.push({
    step: 'Flag Enabled Check',
    description: `Flag is ON in ${environment}. Evaluating rules.`,
    passed: true,
  });

  // 2. Check Individual User Targets
  if (envConfig.individualTargets && envConfig.individualTargets.length > 0) {
    for (const target of envConfig.individualTargets) {
      if (target.userKeys.includes(context.key)) {
        const variation = flag.variations.find((v) => v.id === target.variationId) || flag.variations[0];
        traces.push({
          step: 'Individual Target Match',
          description: `User key "${context.key}" directly matched target for variation "${variation.name}"`,
          passed: true,
        });
        return {
          flagKey: flag.key,
          flagId: flag.id,
          environment,
          userKey: context.key,
          value: variation.value,
          variationKey: variation.key,
          variationId: variation.id,
          variationName: variation.name,
          reason: 'TARGET_MATCH',
          evaluationTimeMs: Number((performance.now() - startTime).toFixed(2)),
          traces,
        };
      }
    }
  }

  traces.push({
    step: 'Individual Target Match',
    description: `User key "${context.key}" did not match individual override lists`,
    passed: false,
  });

  // Calculate bucket score deterministically for this flag + user
  const bucketScore = getBucketScore(flag.key, context.key);

  // 3. Evaluate Targeting Rules in order
  for (let i = 0; i < envConfig.rules.length; i++) {
    const rule = envConfig.rules[i];
    const attributeVal = rule.operator === 'in_segment' ? context : getContextValue(context, rule.attribute);
    const isMatched = evaluateOperator(attributeVal, rule.operator, rule.values, segments);

    if (isMatched) {
      traces.push({
        step: `Rule #${i + 1} (${rule.attribute} ${rule.operator} ${rule.values.join(', ')})`,
        description: `Rule matched for user (${rule.description || 'Custom Rule'})`,
        passed: true,
      });

      let servedVar: Variation;
      if (rule.serveType === 'rollout' && rule.rolloutDistribution && rule.rolloutDistribution.length > 0) {
        servedVar = resolveRolloutVariation(bucketScore, rule.rolloutDistribution, flag.variations, envConfig.offVariationId);
        traces.push({
          step: 'Rule Rollout Bucketing',
          description: `User hash bucket score ${bucketScore}% landed in "${servedVar.name}"`,
          passed: true,
        });
      } else {
        servedVar = flag.variations.find((v) => v.id === rule.serveVariationId) || flag.variations[0];
      }

      return {
        flagKey: flag.key,
        flagId: flag.id,
        environment,
        userKey: context.key,
        value: servedVar.value,
        variationKey: servedVar.key,
        variationId: servedVar.id,
        variationName: servedVar.name,
        reason: 'RULE_MATCH',
        matchedRuleId: rule.id,
        matchedRuleDesc: rule.description || `${rule.attribute} ${rule.operator} [${rule.values.join(', ')}]`,
        bucketScore,
        evaluationTimeMs: Number((performance.now() - startTime).toFixed(2)),
        traces,
      };
    } else {
      traces.push({
        step: `Rule #${i + 1} (${rule.attribute} ${rule.operator} ${rule.values.join(', ')})`,
        description: `Condition not met (User ${rule.attribute} was: "${attributeVal ?? 'undefined'}")`,
        passed: false,
      });
    }
  }

  // 4. Check Canary Rollout (if configured and active)
  if (envConfig.canary && envConfig.canary.enabled && !envConfig.canary.circuitBreakerTripped) {
    const currentStage = envConfig.canary.stages[envConfig.canary.currentStageIndex];
    if (currentStage) {
      const canaryVariation = flag.variations[1] || flag.variations[0]; // Second variation is the new release
      const baselineVariation = flag.variations[0];
      const isCanary = bucketScore < currentStage.percentage;

      traces.push({
        step: `Canary Stage ${currentStage.stage} (${currentStage.percentage}% Rollout)`,
        description: `User bucket ${bucketScore}% is ${isCanary ? '<' : '>='} Canary threshold ${currentStage.percentage}%. Serving ${isCanary ? canaryVariation.name : baselineVariation.name}.`,
        passed: isCanary,
      });

      const selected = isCanary ? canaryVariation : baselineVariation;
      return {
        flagKey: flag.key,
        flagId: flag.id,
        environment,
        userKey: context.key,
        value: selected.value,
        variationKey: selected.key,
        variationId: selected.id,
        variationName: selected.name,
        reason: 'CANARY_ROLLOUT',
        bucketScore,
        evaluationTimeMs: Number((performance.now() - startTime).toFixed(2)),
        traces,
      };
    }
  }

  // 5. Default Fallthrough
  const fallthrough = envConfig.fallthrough;
  let finalVariation: Variation;

  if (fallthrough.type === 'rollout' && fallthrough.rolloutDistribution && fallthrough.rolloutDistribution.length > 0) {
    finalVariation = resolveRolloutVariation(bucketScore, fallthrough.rolloutDistribution, flag.variations, envConfig.offVariationId);
    traces.push({
      step: 'Default Fallthrough Rollout',
      description: `User bucket ${bucketScore}% mapped to variation "${finalVariation.name}"`,
      passed: true,
    });
    return {
      flagKey: flag.key,
      flagId: flag.id,
      environment,
      userKey: context.key,
      value: finalVariation.value,
      variationKey: finalVariation.key,
      variationId: finalVariation.id,
      variationName: finalVariation.name,
      reason: 'FALLTHROUGH_ROLLOUT',
      bucketScore,
      evaluationTimeMs: Number((performance.now() - startTime).toFixed(2)),
      traces,
    };
  } else {
    finalVariation = flag.variations.find((v) => v.id === fallthrough.variationId) || flag.variations[0];
    traces.push({
      step: 'Default Fallthrough Single Variation',
      description: `Served static default variation "${finalVariation.name}"`,
      passed: true,
    });
    return {
      flagKey: flag.key,
      flagId: flag.id,
      environment,
      userKey: context.key,
      value: finalVariation.value,
      variationKey: finalVariation.key,
      variationId: finalVariation.id,
      variationName: finalVariation.name,
      reason: 'DEFAULT_VARIATION',
      bucketScore,
      evaluationTimeMs: Number((performance.now() - startTime).toFixed(2)),
      traces,
    };
  }
}
