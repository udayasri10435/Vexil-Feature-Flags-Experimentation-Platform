import { ExperimentVariationStats } from '../types';

/**
 * Standard Normal Cumulative Distribution Function approximation (Abramowitz & Stegun 26.2.17)
 */
export function normalCDF(z: number): number {
  if (z === 0) return 0.5;
  const b1 = 0.31938153;
  const b2 = -0.356563782;
  const b3 = 1.781477937;
  const b4 = -1.821255978;
  const b5 = 1.330274429;
  const p = 0.2316419;
  const c = 0.39894228;

  const absZ = Math.abs(z);
  const t = 1.0 / (1.0 + p * absZ);
  const val = 1.0 - c * Math.exp((-absZ * absZ) / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1);
  return z > 0 ? val : 1.0 - val;
}

/**
 * Two-tailed p-value from z-score
 */
export function calculatePValue(zScore: number): number {
  const absZ = Math.abs(zScore);
  const p = 2 * (1 - normalCDF(absZ));
  return Math.max(0, Math.min(1, Number(p.toFixed(4))));
}

/**
 * Computes statistical metrics comparing a treatment variation to baseline variation.
 */
export function computeVariationStats(
  sampleSize: number,
  conversions: number,
  baselineSample: number,
  baselineConversions: number,
  confidenceLevel: 90 | 95 | 99 = 95
): {
  conversionRate: number;
  standardError: number;
  zScore: number;
  pValue: number;
  confidenceInterval: [number, number];
  liftPercent: number;
  isSignificant: boolean;
  isWinner: boolean;
} {
  const cr = sampleSize > 0 ? conversions / sampleSize : 0;
  const baselineCr = baselineSample > 0 ? baselineConversions / baselineSample : 0;

  if (sampleSize < 15 || baselineSample < 15 || cr === 0 || baselineCr === 0) {
    return {
      conversionRate: Number((cr * 100).toFixed(2)),
      standardError: 0,
      zScore: 0,
      pValue: 1,
      confidenceInterval: [0, 0],
      liftPercent: 0,
      isSignificant: false,
      isWinner: false,
    };
  }

  // Pooled standard error for two proportions
  const se1 = (cr * (1 - cr)) / sampleSize;
  const se2 = (baselineCr * (1 - baselineCr)) / baselineSample;
  const seDiff = Math.sqrt(se1 + se2);

  const diff = cr - baselineCr;
  const zScore = seDiff > 0 ? diff / seDiff : 0;
  const pValue = calculatePValue(zScore);

  // Critical z based on confidence level
  const criticalZ = confidenceLevel === 99 ? 2.576 : confidenceLevel === 90 ? 1.645 : 1.96;
  const marginOfError = criticalZ * seDiff;

  const ciLower = Number(((diff - marginOfError) * 100).toFixed(2));
  const ciUpper = Number(((diff + marginOfError) * 100).toFixed(2));

  const lift = baselineCr > 0 ? ((cr - baselineCr) / baselineCr) * 100 : 0;

  const alpha = (100 - confidenceLevel) / 100;
  const isSignificant = pValue < alpha && sampleSize >= 50 && baselineSample >= 50;
  const isWinner = isSignificant && lift > 0;

  return {
    conversionRate: Number((cr * 100).toFixed(2)),
    standardError: Number(seDiff.toFixed(4)),
    zScore: Number(zScore.toFixed(3)),
    pValue,
    confidenceInterval: [ciLower, ciUpper],
    liftPercent: Number(lift.toFixed(2)),
    isSignificant,
    isWinner,
  };
}

/**
 * Simulates user traffic generation for an experiment
 */
export function simulateExperimentTraffic(
  currentStats: Record<string, ExperimentVariationStats>,
  totalNewVisitors: number,
  baselineTrueCR: number = 0.12,
  variationsLiftDeltas: Record<string, number> = {},
  baselineVarId: string,
  confidenceLevel: 90 | 95 | 99 = 95
): Record<string, ExperimentVariationStats> {
  const nextStats: Record<string, ExperimentVariationStats> = { ...currentStats };
  const varIds = Object.keys(currentStats);
  const count = varIds.length;
  if (count === 0) return nextStats;

  const visitorsPerVar = Math.floor(totalNewVisitors / count);

  // Step 1: Accumulate samples & conversions with realistic binomial noise
  for (const varId of varIds) {
    const stat = { ...nextStats[varId] };
    const trueCr = Math.max(0.01, baselineTrueCR + (variationsLiftDeltas[varId] || 0));

    let newConversions = 0;
    for (let i = 0; i < visitorsPerVar; i++) {
      if (Math.random() < trueCr) {
        newConversions++;
      }
    }

    stat.sampleSize += visitorsPerVar;
    stat.conversions += newConversions;
    stat.conversionRate = Number(((stat.conversions / stat.sampleSize) * 100).toFixed(2));
    nextStats[varId] = stat;
  }

  // Step 2: Compute stats against baseline
  const baseStat = nextStats[baselineVarId] || nextStats[varIds[0]];
  for (const varId of varIds) {
    if (varId === baselineVarId) {
      nextStats[varId].liftPercent = 0;
      nextStats[varId].pValue = 1;
      nextStats[varId].zScore = 0;
      nextStats[varId].isSignificant = false;
      nextStats[varId].isWinner = false;
      nextStats[varId].confidenceInterval = [0, 0];
      continue;
    }

    const stat = nextStats[varId];
    const computed = computeVariationStats(
      stat.sampleSize,
      stat.conversions,
      baseStat.sampleSize,
      baseStat.conversions,
      confidenceLevel
    );

    nextStats[varId] = {
      ...stat,
      ...computed,
    };
  }

  return nextStats;
}
