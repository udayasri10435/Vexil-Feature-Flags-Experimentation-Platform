export type Environment = 'production' | 'staging' | 'development';

export type FlagVariationType = 'boolean' | 'string' | 'number' | 'json';

export type FlagCategory = 'release' | 'experiment' | 'killswitch' | 'operational';

export interface Variation {
  id: string;
  key: string;
  name: string;
  value: boolean | string | number | Record<string, any>;
  description?: string;
}

export type RuleOperator =
  | 'equals'
  | 'not_equals'
  | 'contains'
  | 'not_contains'
  | 'ends_with'
  | 'starts_with'
  | 'in_list'
  | 'not_in_list'
  | 'greater_than'
  | 'less_than'
  | 'matches_regex'
  | 'in_segment';

export interface TargetingRule {
  id: string;
  description?: string;
  attribute: string; // e.g., 'email', 'plan', 'country', 'appVersion', 'role'
  operator: RuleOperator;
  values: string[]; // e.g., ['@acme.com', 'enterprise', 'US']
  serveType: 'single' | 'rollout';
  serveVariationId?: string;
  rolloutDistribution?: { variationId: string; percentage: number }[];
}

export interface UserTarget {
  variationId: string;
  userKeys: string[];
}

export interface CanaryStage {
  stage: number;
  percentage: number;
  label: string;
  status: 'pending' | 'active' | 'passed' | 'failed';
  errorRatePercent: number;
  latencyP99Ms: number;
}

export interface CanaryConfig {
  enabled: boolean;
  currentStageIndex: number;
  stages: CanaryStage[];
  maxErrorRateThreshold: number;
  autoPromote: boolean;
  circuitBreakerTripped: boolean;
}

export interface EnvironmentConfig {
  enabled: boolean;
  offVariationId: string;
  fallthrough: {
    type: 'single' | 'rollout';
    variationId?: string;
    rolloutDistribution?: { variationId: string; percentage: number }[];
  };
  individualTargets: UserTarget[];
  rules: TargetingRule[];
  canary?: CanaryConfig;
  evaluationCount: number;
}

export interface FeatureFlag {
  id: string;
  key: string;
  name: string;
  description: string;
  type: FlagVariationType;
  category: FlagCategory;
  tags: string[];
  maintainer: string;
  archived: boolean;
  variations: Variation[];
  environments: Record<Environment, EnvironmentConfig>;
  createdAt: string;
  updatedAt: string;
  lastEvaluatedAt?: string;
}

export type MetricType = 'conversion_rate' | 'revenue' | 'duration_ms';

export interface Metric {
  id: string;
  key: string;
  name: string;
  type: MetricType;
  unit?: string;
  goal: 'increase' | 'decrease';
  description?: string;
}

export interface ExperimentVariationStats {
  variationId: string;
  variationName: string;
  trafficAllocation: number;
  sampleSize: number;
  conversions: number;
  conversionRate: number;
  totalRevenue?: number;
  revenuePerUser?: number;
  standardError: number;
  zScore: number;
  pValue: number;
  confidenceInterval: [number, number]; // [lower, upper]
  liftPercent: number;
  isSignificant: boolean;
  isWinner: boolean;
}

export interface Experiment {
  id: string;
  key: string;
  name: string;
  description: string;
  flagId: string;
  environment: Environment;
  status: 'draft' | 'running' | 'paused' | 'concluded';
  hypothesis: string;
  baselineVariationId: string;
  variations: {
    variationId: string;
    trafficAllocation: number; // percentage, e.g. 50
  }[];
  primaryMetric: Metric;
  secondaryMetrics?: Metric[];
  targetSampleSize: number;
  confidenceLevel: 90 | 95 | 99;
  startedAt?: string;
  concludedAt?: string;
  winnerVariationId?: string;
  stats: Record<string, ExperimentVariationStats>; // keyed by variationId
}

export interface Segment {
  id: string;
  key: string;
  name: string;
  description: string;
  rules: {
    attribute: string;
    operator: RuleOperator;
    values: string[];
  }[];
  includedUserKeys: string[];
  excludedUserKeys: string[];
  createdAt: string;
  updatedAt: string;
}

export interface UserContext {
  key: string;
  name?: string;
  email?: string;
  country?: string;
  plan?: 'free' | 'starter' | 'pro' | 'enterprise';
  appVersion?: string;
  role?: 'user' | 'admin' | 'developer' | 'billing';
  isInternal?: boolean;
  customAttributes?: Record<string, string | number | boolean>;
}

export interface EvaluationStepTrace {
  step: string;
  description: string;
  passed: boolean;
  details?: string;
}

export interface EvaluationResult {
  flagKey: string;
  flagId: string;
  environment: Environment;
  userKey: string;
  value: any;
  variationKey: string;
  variationId: string;
  variationName: string;
  reason: 'OFF' | 'TARGET_MATCH' | 'RULE_MATCH' | 'FALLTHROUGH_ROLLOUT' | 'CANARY_ROLLOUT' | 'DEFAULT_VARIATION';
  matchedRuleId?: string;
  matchedRuleDesc?: string;
  bucketScore?: number; // 0 - 100
  evaluationTimeMs: number;
  traces: EvaluationStepTrace[];
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: {
    name: string;
    email: string;
    role: string;
  };
  action:
    | 'FLAG_TOGGLED'
    | 'FLAG_CREATED'
    | 'FLAG_UPDATED'
    | 'KILL_SWITCH_TRIPPED'
    | 'RULE_ADDED'
    | 'EXPERIMENT_STARTED'
    | 'EXPERIMENT_CONCLUDED'
    | 'CANARY_PROMOTED'
    | 'CANARY_ROLLED_BACK'
    | 'SEGMENT_UPDATED';
  entityType: 'flag' | 'experiment' | 'canary' | 'segment';
  entityKey: string;
  entityName: string;
  environment?: Environment;
  summary: string;
  diff?: {
    field: string;
    oldValue: any;
    newValue: any;
  }[];
}
