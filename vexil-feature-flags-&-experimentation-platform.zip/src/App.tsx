import React, { useState } from 'react';
import { FlagProvider } from './context/FlagContext';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { FlagsList } from './components/flags/FlagsList';
import { CreateFlagModal } from './components/flags/CreateFlagModal';
import { ExperimentsList } from './components/experiments/ExperimentsList';
import { CreateExperimentModal } from './components/experiments/CreateExperimentModal';
import { CanaryRolloutsView } from './components/canary/CanaryRolloutsView';
import { SdkPlayground } from './components/simulator/SdkPlayground';
import { LiveDemoStorefront } from './components/simulator/LiveDemoStorefront';
import { SegmentsManager } from './components/segments/SegmentsManager';
import { AuditLogsView } from './components/audit/AuditLogsView';

function AppContent() {
  const [activeTab, setActiveTab] = useState<string>('flags');
  const [createFlagModalOpen, setCreateFlagModalOpen] = useState(false);
  const [createExpModalOpen, setCreateExpModalOpen] = useState(false);
  const [targetPlaygroundFlagKey, setTargetPlaygroundFlagKey] = useState<string | undefined>(undefined);

  const handleOpenPlaygroundForFlag = (flagKey: string) => {
    setTargetPlaygroundFlagKey(flagKey);
    setActiveTab('playground');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenCreateFlag={() => setCreateFlagModalOpen(true)}
        onOpenCreateExp={() => setCreateExpModalOpen(true)}
      />

      {/* Primary Navigation Tabs */}
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1 px-4 lg:px-8 py-6 max-w-7xl w-full mx-auto">
        {activeTab === 'flags' && (
          <FlagsList
            onOpenCreateFlag={() => setCreateFlagModalOpen(true)}
            onOpenPlaygroundForFlag={handleOpenPlaygroundForFlag}
          />
        )}

        {activeTab === 'experiments' && <ExperimentsList />}

        {activeTab === 'canary' && <CanaryRolloutsView />}

        {activeTab === 'playground' && (
          <SdkPlayground initialFlagKey={targetPlaygroundFlagKey} />
        )}

        {activeTab === 'storefront' && <LiveDemoStorefront />}

        {activeTab === 'segments' && <SegmentsManager />}

        {activeTab === 'audit' && <AuditLogsView />}
      </main>

      {/* Create Flag Modal */}
      {createFlagModalOpen && (
        <CreateFlagModal onClose={() => setCreateFlagModalOpen(false)} />
      )}

      {/* Create Experiment Modal */}
      {createExpModalOpen && (
        <CreateExperimentModal onClose={() => setCreateExpModalOpen(false)} />
      )}
    </div>
  );
}

export default function App() {
  return (
    <FlagProvider>
      <AppContent />
    </FlagProvider>
  );
}
